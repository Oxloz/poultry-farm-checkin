// Admin Dashboard JavaScript

// User role management
let currentUserRole = 'IT_ADMIN'; // Default role, will be set from auth
let currentUserName = '';

// Role-based access control
const ROLES = {
    IT_ADMIN: 'IT_ADMIN',
    MANAGER: 'MANAGER'
};

// Features accessible by each role
const ROLE_PERMISSIONS = {
    [ROLES.IT_ADMIN]: {
        canManageUsers: true,
        canViewAllData: true,
        canExportData: true,
        canManagePricing: true,
        canViewFinancials: true
    },
    [ROLES.MANAGER]: {
        canManageUsers: false,
        canViewAllData: true,
        canExportData: true,
        canManagePricing: false,
        canViewFinancials: true
    }
};

document.addEventListener('DOMContentLoaded', function() {
    // Initialize role-based UI
    initializeRoleBasedAccess();
    
    // Initialize tab functionality
    initializeTabs();
    
    // Initialize role switcher for demo
    initializeRoleSwitcher();
    
    // Initialize language switcher
    initializeLanguageSwitcher();
    
    // Initialize theme toggle
    initializeThemeToggle();
    // Elements
    const checkinDataTable = document.getElementById('checkin-data');
    const noDataMessage = document.getElementById('no-data-message');
    const dateFilter = document.getElementById('date-filter');
    const workerFilter = document.getElementById('worker-filter');
    const medicationFilter = document.getElementById('medication-filter');
    const resetFiltersBtn = document.getElementById('reset-filters');
    const exportCsvBtn = document.getElementById('export-csv');
    const totalCheckinsEl = document.getElementById('total-checkins');
    const totalDeadEl = document.getElementById('total-dead');
    const totalMedicationEl = document.getElementById('total-medication');
    const totalFeedEl = document.getElementById('total-feed');
    
    // Worker management elements
    const workerForm = document.getElementById('worker-form');
    const workerUsernameInput = document.getElementById('worker-username');
    const workerPasswordInput = document.getElementById('worker-password');
    const workerFullnameInput = document.getElementById('worker-fullname');
    const addWorkerBtn = document.getElementById('add-worker-btn');
    const cancelEditBtn = document.getElementById('cancel-edit-btn');
    const noWorkersMessage = document.getElementById('no-workers-message');
    const workersTableContainer = document.getElementById('workers-table-container');
    const workersTableBody = document.getElementById('workers-table-body');
    
    // Credentials management elements
    const adminCredentialsForm = document.getElementById('admin-credentials-form');
    const adminUsernameInput = document.getElementById('admin-username');
    const adminPasswordInput = document.getElementById('admin-password');
    const adminFullnameInput = document.getElementById('admin-fullname');
    const updateAdminBtn = document.getElementById('update-admin-btn');
    const cancelAdminEditBtn = document.getElementById('cancel-admin-edit-btn');
    const adminTableContainer = document.getElementById('admin-table-container');
    const adminTableBody = document.getElementById('admin-table-body');
    const noAdminsMessage = document.getElementById('no-admins-message');
    
    const workerCredentialsForm = document.getElementById('worker-credentials-form');
    const workerCredUsernameInput = document.getElementById('worker-cred-username');
    const workerCredPasswordInput = document.getElementById('worker-cred-password');
    const workerCredFullnameInput = document.getElementById('worker-cred-fullname');
    const updateWorkerCredBtn = document.getElementById('update-worker-cred-btn');
    const clearWorkerCredBtn = document.getElementById('clear-worker-cred-btn');
    
    // Medication pricing elements
    const medicationPricingForm = document.getElementById('medication-pricing-form');
    const medicationNameSelect = document.getElementById('medication-name');
    const medicationPriceInput = document.getElementById('medication-price');
    const medicationUnitSelect = document.getElementById('medication-unit');
    const saveMedicationPriceBtn = document.getElementById('save-medication-price-btn');
    const clearPricingFormBtn = document.getElementById('clear-pricing-form-btn');
    const medicationPricesBody = document.getElementById('medication-prices-body');
    const noPricesMessage = document.getElementById('no-prices-message');
    
    // Expense summary elements
    const totalExpenseAmount = document.getElementById('totalExpenseAmount');
    const avgDailyExpense = document.getElementById('avgDailyExpense');
    const mostExpensiveMed = document.getElementById('mostExpensiveMed');
    const expenseBreakdownBody = document.getElementById('expense-breakdown-body');
    const noExpenseDataMessage = document.getElementById('no-expense-data-message');
    const expenseChart = document.getElementById('expenseChart');
    
    // Store all data
    let allCheckinData = [];
    let allWorkers = [];
    let editingWorkerId = null;
    
    // Admin data
    let allAdmins = [];
    let editingAdminId = null;
    let selectedWorkerForCred = null;
    
    // Medication pricing data
    let medicationPrices = [];
    let editingMedicationId = null;
    
    // Chart instances
    let deadChickensChart = null;
    let medicationChart = null;
    let feedChart = null;
    let workerChart = null;
    let weightChart = null;
    let ageChart = null;
    
    // Fetch data on page load
    fetchCheckinData();
    loadWorkers();
    loadAdmins();
    loadMedicationPrices();
    
    // Event listeners for filters
    dateFilter.addEventListener('change', applyFilters);
    workerFilter.addEventListener('change', applyFilters);
    medicationFilter.addEventListener('change', applyFilters);
    resetFiltersBtn.addEventListener('click', resetFilters);
    exportCsvBtn.addEventListener('click', exportToCsv);
    
    // Event listeners for worker management
    if (workerForm) {
        workerForm.addEventListener('submit', handleWorkerSubmit);
    } else {
        console.error('Worker form not found');
    }
    if (cancelEditBtn) {
        cancelEditBtn.addEventListener('click', cancelWorkerEdit);
    }
    
    // Credentials management event listeners
    adminCredentialsForm.addEventListener('submit', handleAdminCredentialsSubmit);
    cancelAdminEditBtn.addEventListener('click', cancelAdminEdit);
    workerCredentialsForm.addEventListener('submit', handleWorkerCredentialsSubmit);
    clearWorkerCredBtn.addEventListener('click', clearWorkerCredentials);
    
    // Medication pricing event listeners
    medicationPricingForm.addEventListener('submit', handleMedicationPricingSubmit);
    clearPricingFormBtn.addEventListener('click', clearMedicationPricingForm);
    
    // Function to fetch check-in data
    function fetchCheckinData() {
        // In a real application, you would use fetch to get data from your backend
        // For this example, we'll simulate fetching data
        
        // Simulated data for demonstration
        // In a real application, replace this with actual fetch call:
        /*
        fetch('../backend/get-checkins.php')
            .then(response => response.json())
            .then(result => {
                if (result.success) {
                    allCheckinData = result.data;
                    populateWorkerFilter(allCheckinData);
                    updateStats(allCheckinData);
                    displayCheckinData(allCheckinData);
                } else {
                    showError(result.message || 'Failed to load data');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showError('Failed to load data. Please try again.');
            });
        */
        
        // Simulated data for demonstration
        setTimeout(() => {
            // Always generate fresh sample data with new worker names
            // Clear any existing data to ensure we use the updated worker names
            localStorage.removeItem('sampleCheckinData');
            
            // Create sample data for demonstration with new worker names
            allCheckinData = generateSampleData();
            // Store in localStorage for demo purposes
            localStorage.setItem('sampleCheckinData', JSON.stringify(allCheckinData));
            
            console.log('Generated sample data with workers:', [...new Set(allCheckinData.map(d => d.workerName))]);
            
            populateWorkerFilter(allCheckinData);
            updateStats(allCheckinData);
            displayCheckinData(allCheckinData);
            initializeCharts(allCheckinData);
            updateExpenseSummary();
        }, 500);
    }
    
    // Function to populate worker filter dropdown
    function populateWorkerFilter(data) {
        const workers = new Set();
        data.forEach(item => {
            workers.add(item.workerName);
        });
        
        // Clear existing options except the first one
        while (workerFilter.options.length > 1) {
            workerFilter.remove(1);
        }
        
        // Add worker options
        workers.forEach(worker => {
            const option = document.createElement('option');
            option.value = worker;
            option.textContent = worker;
            workerFilter.appendChild(option);
        });
    }
    
    // Function to update statistics
    function updateStats(data) {
        const totalCheckins = data.length;
        let totalDead = 0;
        let medicationUses = 0;
        let totalFeed = 0;
        let totalAge = 0;
        let totalWeight = 0;
        let totalChickenCount = 0;
        let latestWeightEntry = null;
        let latestDate = null;
        
        data.forEach(item => {
            totalDead += parseInt(item.deadChickens) || 0;
            
            // Count medication uses from new structure
            if (item.medications) {
                // New structure with time periods
                ['morning', 'afternoon', 'evening'].forEach(period => {
                    if (item.medications[period] && item.medications[period].length > 0) {
                        medicationUses += item.medications[period].length;
                    }
                });
            } else if (item.medication && item.medication !== 'none') {
                // Legacy structure
                medicationUses++;
            }
            
            totalFeed += parseFloat(item.feedAmount) || 0;
            
            // Calculate chicken age and weight statistics
            if (item.chickenAge) {
                totalAge += parseInt(item.chickenAge) || 0;
            }
            
            if (item.weightData) {
                totalWeight += parseFloat(item.weightData.totalWeight) || 0;
                totalChickenCount += parseInt(item.weightData.totalCount) || 0;
                
                // Track latest weight entry
                const itemDate = new Date(item.date);
                if (!latestDate || itemDate > latestDate) {
                    latestDate = itemDate;
                    latestWeightEntry = item.weightData;
                }
            }
        });
        
        // Update existing statistics
        totalCheckinsEl.textContent = totalCheckins;
        totalDeadEl.textContent = totalDead;
        totalMedicationEl.textContent = medicationUses;
        totalFeedEl.textContent = totalFeed.toFixed(1);
        
        // Update new chicken statistics
        const avgChickenAgeEl = document.getElementById('avg-chicken-age');
        const avgChickenWeightEl = document.getElementById('avg-chicken-weight');
        const totalChickenCountEl = document.getElementById('total-chicken-count');
        const latestWeightEntryEl = document.getElementById('latest-weight-entry');
        
        if (avgChickenAgeEl) {
            const avgAge = totalCheckins > 0 ? (totalAge / totalCheckins).toFixed(1) : 0;
            avgChickenAgeEl.textContent = `${avgAge} days`;
        }
        
        if (avgChickenWeightEl) {
            const avgWeight = totalChickenCount > 0 ? (totalWeight / totalChickenCount).toFixed(2) : 0;
            avgChickenWeightEl.textContent = `${avgWeight} kg`;
        }
        
        if (totalChickenCountEl) {
            totalChickenCountEl.textContent = totalChickenCount;
        }
        
        if (latestWeightEntryEl) {
            if (latestWeightEntry) {
                const latestText = `${latestWeightEntry.totalWeight}kg (${latestWeightEntry.totalCount} chickens)`;
                latestWeightEntryEl.textContent = latestText;
            } else {
                latestWeightEntryEl.textContent = 'No data';
            }
        }
    }
    
    // Function to display check-in data
    function displayCheckinData(data) {
        // Clear existing table rows
        checkinDataTable.innerHTML = '';
        
        if (data.length === 0) {
            noDataMessage.style.display = 'block';
            return;
        }
        
        noDataMessage.style.display = 'none';
        
        // Add data rows
        data.forEach(item => {
            const row = document.createElement('tr');
            
            // Format date
            const dateObj = new Date(item.date);
            const formattedDate = dateObj.toLocaleDateString();
            
            // Format medication - handle both new and legacy structures
            let medicationText = 'None';
            let medicationAmount = '-';
            
            if (item.medications) {
                // New structure with time periods
                const allMedications = [];
                ['morning', 'afternoon', 'evening'].forEach(period => {
                    if (item.medications[period] && item.medications[period].length > 0) {
                        item.medications[period].forEach(med => {
                            let medName = med.medication;
                            if (medName === 'other' && med.otherMedication) {
                                medName = med.otherMedication;
                            }
                            const medDisplay = `${period.charAt(0).toUpperCase() + period.slice(1)}: ${medName.charAt(0).toUpperCase() + medName.slice(1)} (${med.amount} ${med.unit})`;
                            allMedications.push(medDisplay);
                        });
                    }
                });
                
                if (allMedications.length > 0) {
                    medicationText = allMedications.join('<br>');
                    medicationAmount = 'See details';
                }
            } else if (item.medication) {
                // Legacy structure
                medicationText = item.medication;
                if (medicationText === 'other' && item.otherMedication) {
                    medicationText = item.otherMedication;
                } else if (medicationText === 'none') {
                    medicationText = 'None';
                } else {
                    // Capitalize first letter
                    medicationText = medicationText.charAt(0).toUpperCase() + medicationText.slice(1);
                }
                
                // Format medication amount for legacy structure
                if (item.medicationAmount && item.medicationAmount !== '0') {
                    medicationAmount = `${item.medicationAmount} ${item.medicationUnit || ''}`;
                }
            }
            
            row.innerHTML = `
                <td>${formattedDate}</td>
                <td>${item.workerName}</td>
                <td>${item.deadChickens}</td>
                <td>${medicationText}</td>
                <td>${medicationAmount}</td>
                <td>${item.feedAmount}</td>
                <td>${item.notes || '-'}</td>
            `;
            
            checkinDataTable.appendChild(row);
        });
    }
    
    // Function to apply filters
    function applyFilters() {
        const dateValue = dateFilter.value;
        const workerValue = workerFilter.value;
        const medicationValue = medicationFilter.value;
        
        let filteredData = allCheckinData;
        
        // Apply date filter
        if (dateValue) {
            filteredData = filteredData.filter(item => item.date === dateValue);
        }
        
        // Apply worker filter
        if (workerValue) {
            filteredData = filteredData.filter(item => item.workerName === workerValue);
        }
        
        // Apply medication filter
        if (medicationValue) {
            filteredData = filteredData.filter(item => item.medication === medicationValue);
        }
        
        // Update stats and display
        updateStats(filteredData);
        displayCheckinData(filteredData);
        updateCharts(filteredData);
        updateExpenseSummary();
    }
    
    // Function to reset filters
    function resetFilters() {
        dateFilter.value = '';
        workerFilter.value = '';
        medicationFilter.value = '';
        
        updateStats(allCheckinData);
        displayCheckinData(allCheckinData);
        updateCharts(allCheckinData);
        updateExpenseSummary();
    }
    
    // Function to export data to CSV
    function exportToCsv() {
        // Get currently filtered data
        const dateValue = dateFilter.value;
        const workerValue = workerFilter.value;
        const medicationValue = medicationFilter.value;
        
        let dataToExport = allCheckinData;
        
        // Apply filters for export
        if (dateValue) {
            dataToExport = dataToExport.filter(item => item.date === dateValue);
        }
        
        if (workerValue) {
            dataToExport = dataToExport.filter(item => item.workerName === workerValue);
        }
        
        if (medicationValue) {
            dataToExport = dataToExport.filter(item => item.medication === medicationValue);
        }
        
        if (dataToExport.length === 0) {
            alert('No data to export');
            return;
        }
        
        // CSV headers
        const headers = ['Date', 'Worker Name', 'Dead Chickens', 'Medication', 'Medication Amount', 'Medication Cost', 'Feed Amount (kg)', 'Notes'];
        
        // Format data for CSV
        const csvData = dataToExport.map(item => {
            // Format medication for CSV - handle both new and legacy structures
            let medicationText = 'None';
            let medicationAmount = '';
            let medicationCost = '$0.00';
            
            if (item.medications) {
                // New structure with time periods
                const allMedications = [];
                let totalCost = 0;
                
                ['morning', 'afternoon', 'evening'].forEach(period => {
                    if (item.medications[period] && item.medications[period].length > 0) {
                        item.medications[period].forEach(med => {
                            let medName = med.medication;
                            if (medName === 'other' && med.otherMedication) {
                                medName = med.otherMedication;
                            }
                            allMedications.push(`${period}: ${medName} (${med.amount} ${med.unit})`);
                            
                            // Calculate cost for this medication
                            const cost = calculateSingleMedicationCost(med.medication, med.amount, med.unit);
                            totalCost += cost;
                        });
                    }
                });
                
                if (allMedications.length > 0) {
                    medicationText = allMedications.join('; ');
                    medicationAmount = 'Multiple entries';
                    medicationCost = `RM ${totalCost.toFixed(2)}`;
                }
            } else if (item.medication) {
                // Legacy structure
                medicationText = item.medication;
                if (medicationText === 'other' && item.otherMedication) {
                    medicationText = item.otherMedication;
                } else if (medicationText === 'none') {
                    medicationText = 'None';
                }
                
                if (item.medicationAmount && item.medicationAmount !== '0') {
                    medicationAmount = `${item.medicationAmount} ${item.medicationUnit || ''}`;
                    
                    // Calculate cost for legacy medication
                    const cost = calculateSingleMedicationCost(item.medication, item.medicationAmount, item.medicationUnit);
                    medicationCost = `RM ${cost.toFixed(2)}`;
                }
            }
            
            return [
                item.date,
                item.workerName,
                item.deadChickens,
                medicationText,
                medicationAmount,
                medicationCost,
                item.feedAmount,
                item.notes || ''
            ];
        });
        
        // Combine headers and data
        const csvContent = [
            headers.join(','),
            ...csvData.map(row => row.map(cell => `"${cell}"`).join(','))
        ].join('\n');
        
        // Create download link
        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.setAttribute('href', url);
        link.setAttribute('download', `poultry-farm-checkins-${new Date().toISOString().slice(0, 10)}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    }
    
    // Function to show error message
    function showError(message) {
        noDataMessage.textContent = message;
        noDataMessage.classList.remove('alert-info');
        noDataMessage.classList.add('alert-danger');
        noDataMessage.style.display = 'block';
    }
    
    // Function to generate sample data for demonstration
    function generateSampleData() {
        const workers = ['Labir', 'Surya', 'Xingmei', 'Dicky', 'Jaya', 'Nandir'];
        const medications = ['Doxi', 'Fofenicol', 'VP 1000', 'none'];
        const units = ['ml', 'g'];
        
        const sampleData = [];
        const today = new Date();
        
        // Generate 30 sample entries for better data visualization
        for (let i = 0; i < 30; i++) {
            const date = new Date(today);
            date.setDate(date.getDate() - Math.floor(Math.random() * 30)); // Random date within last 30 days
            
            const worker = workers[Math.floor(Math.random() * workers.length)];
            const deadChickens = Math.floor(Math.random() * 5); // 0-4 dead chickens
            const feedAmount = (50 + Math.random() * 50).toFixed(1); // 50-100 kg
            
            // Generate medications for different time periods
            const medications_data = {
                morning: [],
                afternoon: [],
                evening: []
            };
            
            // Randomly add medications to different periods
            ['morning', 'afternoon', 'evening'].forEach(period => {
                if (Math.random() > 0.4) { // 60% chance of having medication in each period
                    const medication = medications[Math.floor(Math.random() * medications.length)];
                    if (medication !== 'none') {
                        const amount = (Math.random() * 5 + 1).toFixed(1); // 1-6 ml/g
                        const unit = units[Math.floor(Math.random() * units.length)];
                        
                        medications_data[period].push({
                            medication: medication,
                            amount: amount,
                            unit: unit
                        });
                    }
                }
            });
            
            sampleData.push({
                id: `sample-${i}`,
                date: date.toISOString().slice(0, 10),
                workerName: worker,
                deadChickens: deadChickens.toString(),
                medications: medications_data,
                feedAmount: feedAmount,
                notes: deadChickens > 0 ? 'Some chickens showed signs of illness before death.' : '',
                chickenAge: Math.floor(Math.random() * 50 + 10), // 10-60 days
                weightData: {
                    totalWeight: (Math.random() * 100 + 50).toFixed(1), // 50-150 kg
                    averageWeight: (Math.random() * 2 + 1).toFixed(2) // 1-3 kg per chicken
                }
            });
        }
        
        // Sort by date (newest first)
        sampleData.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        return sampleData;
    }
    
    // Function to initialize charts
    function initializeCharts(data) {
        createDeadChickensChart(data);
        createMedicationChart(data);
        createFeedChart(data);
        createWorkerChart(data);
        createWeightChart(data);
        createAgeChart(data);
    }
    
    // Function to update charts when filters are applied
    function updateCharts(data) {
        updateDeadChickensChart(data);
        updateMedicationChart(data);
        updateFeedChart(data);
        updateWorkerChart(data);
        updateWeightChart(data);
        updateAgeChart(data);
        updateExpenseSummary();
    }
    
    // Dead Chickens Trend Chart
    function createDeadChickensChart(data) {
        const ctx = document.getElementById('deadChickensChart').getContext('2d');
        const chartData = getDeadChickensChartData(data);
        
        deadChickensChart = new Chart(ctx, {
            type: 'line',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Dead Chickens'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    function updateDeadChickensChart(data) {
        if (deadChickensChart) {
            const chartData = getDeadChickensChartData(data);
            deadChickensChart.data = chartData;
            deadChickensChart.update();
        }
    }
    
    function getDeadChickensChartData(data) {
        // Get last 7 days
        const last7Days = [];
        const today = new Date();
        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            last7Days.push(date.toISOString().slice(0, 10));
        }
        
        const dailyTotals = last7Days.map(date => {
            const dayData = data.filter(item => item.date === date);
            const total = dayData.reduce((sum, item) => sum + (parseInt(item.deadChickens) || 0), 0);
            return total;
        });
        
        return {
            labels: last7Days.map(date => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
            datasets: [{
                label: 'Dead Chickens',
                data: dailyTotals,
                borderColor: '#dc3545',
                backgroundColor: 'rgba(220, 53, 69, 0.1)',
                tension: 0.4,
                fill: true
            }]
        };
    }
    
    // Medication Usage Distribution Chart
    function createMedicationChart(data) {
        const ctx = document.getElementById('medicationChart').getContext('2d');
        const chartData = getMedicationChartData(data);
        
        medicationChart = new Chart(ctx, {
            type: 'doughnut',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    }
    
    function updateMedicationChart(data) {
        if (medicationChart) {
            const chartData = getMedicationChartData(data);
            medicationChart.data = chartData;
            medicationChart.update();
        }
    }
    
    function getMedicationChartData(data) {
        const medicationCounts = {};
        
        data.forEach(item => {
            if (item.medications && typeof item.medications === 'object' && !Array.isArray(item.medications)) {
                // New structure with time periods - aggregate by medication type
                ['morning', 'afternoon', 'evening'].forEach(period => {
                    if (item.medications[period] && item.medications[period].length > 0) {
                        item.medications[period].forEach(med => {
                            let medication = med.medication;
                            if (medication === 'other' && med.otherMedication) {
                                medication = med.otherMedication;
                            }
                            
                            if (medication && medication !== 'none') {
                                medicationCounts[medication] = (medicationCounts[medication] || 0) + 1;
                            }
                        });
                    }
                });
            } else if (item.medications && Array.isArray(item.medications)) {
                // Legacy array structure
                item.medications.forEach(med => {
                    let medication = med.medication;
                    if (medication === 'other' && med.otherMedication) {
                        medication = med.otherMedication;
                    }
                    
                    if (medication && medication !== 'none') {
                        medicationCounts[medication] = (medicationCounts[medication] || 0) + 1;
                    }
                });
            } else if (item.medication) {
                // Legacy single medication structure
                let medication = item.medication;
                if (medication === 'other' && item.otherMedication) {
                    medication = item.otherMedication;
                }
                
                if (medication && medication !== 'none') {
                    medicationCounts[medication] = (medicationCounts[medication] || 0) + 1;
                }
            }
        });
        
        const labels = Object.keys(medicationCounts).map(med => {
            return med === 'none' ? 'None' : med.charAt(0).toUpperCase() + med.slice(1);
        });
        const values = Object.values(medicationCounts);
        
        const colors = [
            '#28a745', '#dc3545', '#ffc107', '#17a2b8', '#6f42c1',
            '#fd7e14', '#20c997', '#e83e8c', '#6c757d', '#343a40'
        ];
        
        return {
            labels: labels,
            datasets: [{
                data: values,
                backgroundColor: colors.slice(0, labels.length),
                borderWidth: 2,
                borderColor: '#fff'
            }]
        };
    }
    
    // Feed Consumption Trend Chart
    function createFeedChart(data) {
        const ctx = document.getElementById('feedChart').getContext('2d');
        const chartData = getFeedChartData(data);
        
        feedChart = new Chart(ctx, {
            type: 'bar',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Feed Amount (kg)'
                        }
                    },
                    x: {
                        title: {
                            display: true,
                            text: 'Date'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    function updateFeedChart(data) {
        if (feedChart) {
            const chartData = getFeedChartData(data);
            feedChart.data = chartData;
            feedChart.update();
        }
    }
    
    function getFeedChartData(data) {
        // Get last 7 days
        const last7Days = [];
        const today = new Date();
        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            last7Days.push(date.toISOString().slice(0, 10));
        }
        
        const dailyTotals = last7Days.map(date => {
            const dayData = data.filter(item => item.date === date);
            const total = dayData.reduce((sum, item) => sum + (parseFloat(item.feedAmount) || 0), 0);
            return total;
        });
        
        return {
            labels: last7Days.map(date => new Date(date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })),
            datasets: [{
                label: 'Feed Amount',
                data: dailyTotals,
                backgroundColor: '#28a745',
                borderColor: '#1e7e34',
                borderWidth: 1
            }]
        };
    }
    
    // Worker Activity Chart
    function createWorkerChart(data) {
        const ctx = document.getElementById('workerChart').getContext('2d');
        const chartData = getWorkerChartData(data);
        
        workerChart = new Chart(ctx, {
            type: 'bar',
            data: chartData,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                indexAxis: 'y',
                scales: {
                    x: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Check-ins'
                        }
                    }
                },
                plugins: {
                    legend: {
                        display: false
                    }
                }
            }
        });
    }
    
    function updateWorkerChart(data) {
        if (workerChart) {
            const chartData = getWorkerChartData(data);
            workerChart.data = chartData;
            workerChart.update();
        }
    }
    
    function getWorkerChartData(data) {
        const workerCounts = {};
        
        data.forEach(item => {
            workerCounts[item.workerName] = (workerCounts[item.workerName] || 0) + 1;
        });
        
        const labels = Object.keys(workerCounts);
        const values = Object.values(workerCounts);
        
        return {
            labels: labels,
            datasets: [{
                label: 'Check-ins',
                data: values,
                backgroundColor: '#17a2b8',
                borderColor: '#138496',
                borderWidth: 1
            }]
         };
     }
     
     // Weight Chart Functions
     function createWeightChart(data) {
         const ctx = document.getElementById('weightChart').getContext('2d');
         const chartData = getWeightChartData(data);
         
         weightChart = new Chart(ctx, {
             type: 'line',
             data: chartData,
             options: {
                 responsive: true,
                 plugins: {
                     title: {
                         display: true,
                         text: 'Chicken Weight Trend (Last 7 Days)'
                     }
                 },
                 scales: {
                     y: {
                         beginAtZero: true,
                         title: {
                             display: true,
                             text: 'Average Weight (kg)'
                         }
                     },
                     x: {
                         title: {
                             display: true,
                             text: 'Date'
                         }
                     }
                 }
             }
         });
     }
     
     function updateWeightChart(data) {
         if (weightChart) {
             const chartData = getWeightChartData(data);
             weightChart.data = chartData;
             weightChart.update();
         }
     }
     
     function getWeightChartData(data) {
         const last7Days = [];
         const today = new Date();
         
         for (let i = 6; i >= 0; i--) {
             const date = new Date(today);
             date.setDate(date.getDate() - i);
             last7Days.push(date.toISOString().split('T')[0]);
         }
         
         const weightData = last7Days.map(date => {
             const dayData = data.filter(item => item.date === date && item.weightData);
             if (dayData.length === 0) return 0;
             
             let totalWeight = 0;
             let totalCount = 0;
             
             dayData.forEach(item => {
                 if (item.weightData.totalWeight && item.weightData.totalCount) {
                     totalWeight += parseFloat(item.weightData.totalWeight);
                     totalCount += parseInt(item.weightData.totalCount);
                 }
             });
             
             return totalCount > 0 ? (totalWeight / totalCount).toFixed(2) : 0;
         });
         
         return {
             labels: last7Days.map(date => new Date(date).toLocaleDateString()),
             datasets: [{
                 label: 'Average Weight (kg)',
                 data: weightData,
                 backgroundColor: 'rgba(54, 162, 235, 0.2)',
                 borderColor: 'rgba(54, 162, 235, 1)',
                 borderWidth: 2,
                 fill: true
             }]
         };
     }
     
     // Age Chart Functions
     function createAgeChart(data) {
         const ctx = document.getElementById('ageChart').getContext('2d');
         const chartData = getAgeChartData(data);
         
         ageChart = new Chart(ctx, {
             type: 'doughnut',
             data: chartData,
             options: {
                 responsive: true,
                 plugins: {
                     title: {
                         display: true,
                         text: 'Chicken Age Distribution'
                     },
                     legend: {
                         position: 'bottom'
                     }
                 }
             }
         });
     }
     
     function updateAgeChart(data) {
         if (ageChart) {
             const chartData = getAgeChartData(data);
             ageChart.data = chartData;
             ageChart.update();
         }
     }
     
     function getAgeChartData(data) {
         const ageRanges = {
             '0-7 days': 0,
             '8-17 days': 0,
             '18-30 days': 0,
             '31-60 days': 0,
             '60+ days': 0
         };
         
         data.forEach(item => {
             if (item.chickenAge) {
                 const age = parseInt(item.chickenAge);
                 if (age <= 7) ageRanges['0-7 days']++;
                 else if (age <= 17) ageRanges['8-17 days']++;
                 else if (age <= 30) ageRanges['18-30 days']++;
                 else if (age <= 60) ageRanges['31-60 days']++;
                 else ageRanges['60+ days']++;
             }
         });
         
         return {
             labels: Object.keys(ageRanges),
             datasets: [{
                 data: Object.values(ageRanges),
                 backgroundColor: [
                     'rgba(255, 99, 132, 0.8)',
                     'rgba(54, 162, 235, 0.8)',
                     'rgba(255, 205, 86, 0.8)',
                     'rgba(75, 192, 192, 0.8)',
                     'rgba(153, 102, 255, 0.8)'
                 ],
                 borderColor: [
                     'rgba(255, 99, 132, 1)',
                     'rgba(54, 162, 235, 1)',
                     'rgba(255, 205, 86, 1)',
                     'rgba(75, 192, 192, 1)',
                     'rgba(153, 102, 255, 1)'
                 ],
                 borderWidth: 1
             }]
         };
     }
     
     // Worker Management Functions
     function loadWorkers() {
        const storedWorkers = localStorage.getItem('poultryWorkers');
        if (storedWorkers) {
            allWorkers = JSON.parse(storedWorkers);
        } else {
            // Create default workers matching sample data names
            allWorkers = [
                { id: 'worker1', username: 'Labir', password: 'worker123', fullName: 'Labir' },
                { id: 'worker2', username: 'Surya', password: 'worker123', fullName: 'Surya' },
                { id: 'worker3', username: 'Xingmei', password: 'worker123', fullName: 'Xingmei' },
                { id: 'worker4', username: 'Dicky', password: 'worker123', fullName: 'Dicky' },
                { id: 'worker5', username: 'Jaya', password: 'worker123', fullName: 'Jaya' },
                { id: 'worker6', username: 'Nandir', password: 'worker123', fullName: 'Nandir' }
            ];
            localStorage.setItem('poultryWorkers', JSON.stringify(allWorkers));
        }
        displayWorkers();
    }
     
     // Admin credentials management functions
     function loadAdmins() {
         const savedAdmins = localStorage.getItem('admins');
         if (savedAdmins) {
             allAdmins = JSON.parse(savedAdmins);
         } else {
             // Default admins
             allAdmins = [
                 { id: 'admin1', username: 'admin', password: 'admin123', fullName: 'Administrator' },
                 { id: 'admin2', username: 'manager', password: 'manager123', fullName: 'Farm Manager' },
                 { id: 'admin3', username: 'Jabez', password: 'pass', fullName: 'Jabez Admin' }
             ];
             localStorage.setItem('admins', JSON.stringify(allAdmins));
         }
         displayAdmins();
     }
     
     function displayAdmins() {
         if (allAdmins.length === 0) {
             adminTableContainer.style.display = 'none';
             noAdminsMessage.style.display = 'block';
             return;
         }
         
         adminTableContainer.style.display = 'block';
         noAdminsMessage.style.display = 'none';
         
         adminTableBody.innerHTML = '';
         allAdmins.forEach(admin => {
             const row = document.createElement('tr');
             row.innerHTML = `
                 <td>${admin.username}</td>
                 <td>••••••••</td>
                 <td>${admin.fullName}</td>
                 <td>
                     <button class="btn btn-sm btn-primary" onclick="editAdmin('${admin.id}')">
                         <i class="fas fa-edit"></i> Edit
                     </button>
                     <button class="btn btn-sm btn-danger" onclick="deleteAdmin('${admin.id}')">
                         <i class="fas fa-trash"></i> Delete
                     </button>
                 </td>
             `;
             adminTableBody.appendChild(row);
         });
     }
     
     function displayWorkers() {
         if (allWorkers.length === 0) {
             noWorkersMessage.style.display = 'block';
             workersTableContainer.style.display = 'none';
             return;
         }
         
         noWorkersMessage.style.display = 'none';
         workersTableContainer.style.display = 'block';
         
         workersTableBody.innerHTML = '';
         
         allWorkers.forEach(worker => {
             const row = document.createElement('tr');
             row.innerHTML = `
                 <td>${worker.username}</td>
                 <td>${worker.fullName}</td>
                 <td>
                     <button class="btn btn-edit me-1" onclick="editWorker('${worker.id}')">Edit</button>
                     <button class="btn btn-delete" onclick="deleteWorker('${worker.id}')">Delete</button>
                 </td>
             `;
             workersTableBody.appendChild(row);
         });
     }
     
     function handleWorkerSubmit(e) {
         e.preventDefault();
         console.log('Worker form submitted');
         
         if (!workerUsernameInput || !workerPasswordInput || !workerFullnameInput) {
             console.error('Worker form inputs not found');
             alert('Form elements not found. Please refresh the page.');
             return;
         }
         
         const username = workerUsernameInput.value.trim();
         const password = workerPasswordInput.value.trim();
         const fullName = workerFullnameInput.value.trim();
         
         console.log('Form values:', { username, password: '***', fullName });
         
         if (!username || !password || !fullName) {
             alert('Please fill in all fields');
             return;
         }
         
         // Check if username already exists (except when editing)
         const existingWorker = allWorkers.find(w => w.username === username && w.id !== editingWorkerId);
         if (existingWorker) {
             alert('Username already exists. Please choose a different username.');
             return;
         }
         
         if (editingWorkerId) {
             // Update existing worker
             const workerIndex = allWorkers.findIndex(w => w.id === editingWorkerId);
             if (workerIndex !== -1) {
                 allWorkers[workerIndex] = {
                     ...allWorkers[workerIndex],
                     username: username,
                     password: password,
                     fullName: fullName
                 };
             }
             editingWorkerId = null;
             addWorkerBtn.textContent = 'Add Worker';
             cancelEditBtn.style.display = 'none';
         } else {
             // Add new worker
             const newWorker = {
                 id: 'worker_' + Date.now(),
                 username: username,
                 password: password,
                 fullName: fullName
             };
             allWorkers.push(newWorker);
         }
         
         // Save to localStorage
         localStorage.setItem('poultryWorkers', JSON.stringify(allWorkers));
         
         // Reset form
         workerForm.reset();
         
         // Refresh display
         displayWorkers();
         
         // Show success message
         alert(editingWorkerId ? 'Worker updated successfully!' : 'Worker added successfully!');
     }
     
     function editWorker(workerId) {
         const worker = allWorkers.find(w => w.id === workerId);
         if (!worker) return;
         
         workerUsernameInput.value = worker.username;
         workerPasswordInput.value = worker.password;
         workerFullnameInput.value = worker.fullName;
         
         editingWorkerId = workerId;
         addWorkerBtn.textContent = 'Update Worker';
         cancelEditBtn.style.display = 'inline-block';
     }
     
     function cancelWorkerEdit() {
         workerForm.reset();
         editingWorkerId = null;
         addWorkerBtn.textContent = 'Add Worker';
         cancelEditBtn.style.display = 'none';
     }
     
     function deleteWorker(workerId) {
         const worker = allWorkers.find(w => w.id === workerId);
         if (!worker) return;
         
         if (confirm(`Are you sure you want to delete worker "${worker.fullName}"?`)) {
             allWorkers = allWorkers.filter(w => w.id !== workerId);
             localStorage.setItem('poultryWorkers', JSON.stringify(allWorkers));
             displayWorkers();
             
             // Clear form if we were editing this worker
             if (editingWorkerId === workerId) {
                 cancelWorkerEdit();
             }
             
             alert('Worker deleted successfully!');
         }
     }
     
     // Admin credentials form handling
     function handleAdminCredentialsSubmit(e) {
         e.preventDefault();
         
         const username = adminUsernameInput.value.trim();
         const password = adminPasswordInput.value.trim();
         const fullName = adminFullnameInput.value.trim();
         
         if (!username || !password || !fullName) {
             alert('Please fill in all fields');
             return;
         }
         
         if (editingAdminId) {
             // Update existing admin
             const adminIndex = allAdmins.findIndex(admin => admin.id === editingAdminId);
             if (adminIndex !== -1) {
                 // Check if username is taken by another admin
                 const existingAdmin = allAdmins.find(admin => admin.username === username && admin.id !== editingAdminId);
                 if (existingAdmin) {
                     alert('Username already exists');
                     return;
                 }
                 
                 allAdmins[adminIndex] = {
                     ...allAdmins[adminIndex],
                     username,
                     password,
                     fullName
                 };
             }
         } else {
             // Add new admin
             const existingAdmin = allAdmins.find(admin => admin.username === username);
             if (existingAdmin) {
                 alert('Username already exists');
                 return;
             }
             
             const newAdmin = {
                 id: 'admin_' + Date.now(),
                 username,
                 password,
                 fullName
             };
             allAdmins.push(newAdmin);
         }
         
         localStorage.setItem('admins', JSON.stringify(allAdmins));
         displayAdmins();
         cancelAdminEdit();
     }
     
     function editAdmin(adminId) {
         const admin = allAdmins.find(a => a.id === adminId);
         if (admin) {
             editingAdminId = adminId;
             adminUsernameInput.value = admin.username;
             adminPasswordInput.value = admin.password;
             adminFullnameInput.value = admin.fullName;
             updateAdminBtn.textContent = 'Update Admin';
             cancelAdminEditBtn.style.display = 'inline-block';
         }
     }
     
     function cancelAdminEdit() {
         editingAdminId = null;
         adminCredentialsForm.reset();
         updateAdminBtn.textContent = 'Add Admin';
         cancelAdminEditBtn.style.display = 'none';
     }
     
     function deleteAdmin(adminId) {
         if (allAdmins.length <= 1) {
             alert('Cannot delete the last admin account');
             return;
         }
         
         if (confirm('Are you sure you want to delete this admin?')) {
             allAdmins = allAdmins.filter(admin => admin.id !== adminId);
             localStorage.setItem('admins', JSON.stringify(allAdmins));
             displayAdmins();
             
             // Clear form if we were editing this admin
             if (editingAdminId === adminId) {
                 cancelAdminEdit();
             }
         }
     }
     
     // Worker credentials quick edit functions
     function handleWorkerCredentialsSubmit(e) {
         e.preventDefault();
         
         const username = workerCredUsernameInput.value.trim();
         const password = workerCredPasswordInput.value.trim();
         const fullName = workerCredFullnameInput.value.trim();
         
         if (!username) {
             alert('Please enter a username to search for');
             return;
         }
         
         const workerIndex = allWorkers.findIndex(worker => worker.username === username);
         if (workerIndex === -1) {
             alert('Worker not found');
             return;
         }
         
         if (password) {
             allWorkers[workerIndex].password = password;
         }
         if (fullName) {
             allWorkers[workerIndex].fullName = fullName;
         }
         
         localStorage.setItem('poultryWorkers', JSON.stringify(allWorkers));
         displayWorkers();
         clearWorkerCredentials();
         alert('Worker credentials updated successfully');
     }
     
     function clearWorkerCredentials() {
         workerCredentialsForm.reset();
         selectedWorkerForCred = null;
     }
     
     // Medication pricing management functions
    function loadMedicationPrices() {
        const savedPrices = localStorage.getItem('medicationPrices');
        if (savedPrices) {
            medicationPrices = JSON.parse(savedPrices);
        } else {
            // Default medication prices
            medicationPrices = [
                { id: 'price1', medication: 'Doxi', price: 2.50, unit: 'ml', lastUpdated: new Date().toISOString() },
                { id: 'price2', medication: 'Fofenicol', price: 3.75, unit: 'ml', lastUpdated: new Date().toISOString() },
                { id: 'price3', medication: 'VP 1000', price: 1.25, unit: 'ml', lastUpdated: new Date().toISOString() }
            ];
            localStorage.setItem('medicationPrices', JSON.stringify(medicationPrices));
        }
        displayMedicationPrices();
    }
    
    function displayMedicationPrices() {
        if (medicationPrices.length === 0) {
            medicationPricesBody.innerHTML = '';
            noPricesMessage.style.display = 'block';
            return;
        }
        
        noPricesMessage.style.display = 'none';
        medicationPricesBody.innerHTML = medicationPrices.map(price => `
            <tr>
                <td style="font-weight: 500;">${price.medication}</td>
                <td>RM ${price.price.toFixed(2)}</td>
                <td>${price.unit}</td>
                <td>${new Date(price.lastUpdated).toLocaleDateString()}</td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="editMedicationPrice('${price.id}')" style="margin-right: 5px;">Edit</button>
                    <button class="btn btn-sm btn-outline-danger" onclick="deleteMedicationPrice('${price.id}')">Delete</button>
                </td>
            </tr>
        `).join('');
    }
    
    function handleMedicationPricingSubmit(e) {
        e.preventDefault();
        
        const medication = medicationNameSelect.value.trim();
        const price = parseFloat(medicationPriceInput.value);
        const unit = medicationUnitSelect.value;
        
        if (!medication || isNaN(price) || price < 0) {
            alert('Please select a medication and enter a valid price');
            return;
        }
        
        if (editingMedicationId) {
            // Update existing price
            const priceIndex = medicationPrices.findIndex(p => p.id === editingMedicationId);
            if (priceIndex !== -1) {
                medicationPrices[priceIndex] = {
                    ...medicationPrices[priceIndex],
                    medication: medication,
                    price: price,
                    unit: unit,
                    lastUpdated: new Date().toISOString()
                };
            }
            editingMedicationId = null;
            saveMedicationPriceBtn.textContent = 'Save Price';
        } else {
            // Check if medication already has a price
            const existingPrice = medicationPrices.find(p => p.medication === medication);
            if (existingPrice) {
                if (confirm(`${medication} already has a price set. Do you want to update it?`)) {
                    const priceIndex = medicationPrices.findIndex(p => p.medication === medication);
                    medicationPrices[priceIndex] = {
                        ...medicationPrices[priceIndex],
                        price: price,
                        unit: unit,
                        lastUpdated: new Date().toISOString()
                    };
                } else {
                    return;
                }
            } else {
                // Add new price
                const newPrice = {
                    id: 'price_' + Date.now(),
                    medication: medication,
                    price: price,
                    unit: unit,
                    lastUpdated: new Date().toISOString()
                };
                medicationPrices.push(newPrice);
            }
        }
        
        // Save to localStorage
        localStorage.setItem('medicationPrices', JSON.stringify(medicationPrices));
        
        // Reset form
        clearMedicationPricingForm();
        
        // Refresh display
        displayMedicationPrices();
        
        // Update expense summary with new pricing
        updateExpenseSummary();
        
        // Update medication chart to reflect pricing changes
        if (allCheckinData && allCheckinData.length > 0) {
            updateMedicationChart(allCheckinData);
        }
        
        // Show success message
        alert('Medication price saved successfully!');
    }
    
    function editMedicationPrice(priceId) {
        const price = medicationPrices.find(p => p.id === priceId);
        if (!price) return;
        
        medicationNameSelect.value = price.medication;
        medicationPriceInput.value = price.price;
        medicationUnitSelect.value = price.unit;
        
        editingMedicationId = priceId;
        saveMedicationPriceBtn.textContent = 'Update Price';
    }
    
    function deleteMedicationPrice(priceId) {
        const price = medicationPrices.find(p => p.id === priceId);
        if (!price) return;
        
        if (confirm(`Are you sure you want to delete the price for "${price.medication}"?`)) {
            medicationPrices = medicationPrices.filter(p => p.id !== priceId);
            localStorage.setItem('medicationPrices', JSON.stringify(medicationPrices));
            displayMedicationPrices();
            
            // Clear form if we were editing this price
            if (editingMedicationId === priceId) {
                clearMedicationPricingForm();
            }
            
            // Update expense summary after price deletion
            updateExpenseSummary();
            
            // Update medication chart to reflect pricing changes
            if (allCheckinData && allCheckinData.length > 0) {
                updateMedicationChart(allCheckinData);
            }
            
            alert('Medication price deleted successfully!');
        }
    }
    
    function clearMedicationPricingForm() {
        medicationPricingForm.reset();
        editingMedicationId = null;
        saveMedicationPriceBtn.textContent = 'Save Price';
    }
    
    // Medication expense calculation functions
    function calculateMedicationExpenses(checkinData) {
        let totalExpenses = 0;
        const expensesByMedication = {};
        
        checkinData.forEach(entry => {
            if (entry.medications && typeof entry.medications === 'object' && !Array.isArray(entry.medications)) {
                // New medication structure with time periods
                ['morning', 'afternoon', 'evening'].forEach(period => {
                    if (entry.medications[period] && Array.isArray(entry.medications[period])) {
                        entry.medications[period].forEach(med => {
                            if (med.medication && med.medication !== 'none') {
                                const expense = calculateSingleMedicationCost(med.medication, med.amount, med.unit);
                                totalExpenses += expense;
                                
                                const key = med.medication;
                                if (!expensesByMedication[key]) {
                                    expensesByMedication[key] = 0;
                                }
                                expensesByMedication[key] += expense;
                            }
                        });
                    }
                });
            } else if (entry.medications && Array.isArray(entry.medications)) {
                // Legacy array structure
                entry.medications.forEach(med => {
                    if (med.medication && med.medication !== 'none') {
                        const expense = calculateSingleMedicationCost(med.medication, med.amount, med.unit);
                        totalExpenses += expense;
                        
                        if (!expensesByMedication[med.medication]) {
                            expensesByMedication[med.medication] = 0;
                        }
                        expensesByMedication[med.medication] += expense;
                    }
                });
            } else if (entry.medication) {
                // Legacy single medication structure
                const expense = calculateSingleMedicationCost(entry.medication, entry.medicationAmount, entry.medicationUnit);
                totalExpenses += expense;
                
                if (!expensesByMedication[entry.medication]) {
                    expensesByMedication[entry.medication] = 0;
                }
                expensesByMedication[entry.medication] += expense;
            }
        });
        
        return {
            total: totalExpenses,
            byMedication: expensesByMedication
        };
    }
    
    function calculateSingleMedicationCost(medicationName, amount, unit) {
        if (!medicationName || !amount) return 0;
        
        // Handle "other" medications
        if (medicationName.toLowerCase() === 'other') {
            return 0; // No cost calculation for custom medications
        }
        
        // Find the medication price
        const medicationPrice = medicationPrices.find(price => 
            price.medication.toLowerCase() === medicationName.toLowerCase()
        );
        
        if (!medicationPrice) {
            return 0; // No price set for this medication
        }
        
        // Convert amount to the pricing unit if needed
        const convertedAmount = convertMedicationUnit(amount, unit, medicationPrice.unit);
        
        return convertedAmount * medicationPrice.price;
    }
    
    function convertMedicationUnit(amount, fromUnit, toUnit) {
        // Simple unit conversion - can be expanded as needed
        if (fromUnit === toUnit) {
            return amount;
        }
        
        // Basic conversions
        const conversions = {
            'g_mg': 1000,
            'mg_g': 0.001,
            'ml_l': 0.001,
            'l_ml': 1000
        };
        
        const conversionKey = `${fromUnit}_${toUnit}`;
        if (conversions[conversionKey]) {
            return amount * conversions[conversionKey];
        }
        
        // If no conversion available, return original amount
        return amount;
    }
    
    function getMedicationPrice(medicationName) {
        const price = medicationPrices.find(p => 
            p.medication.toLowerCase() === medicationName.toLowerCase()
        );
        return price ? price.price : 0;
    }
    
    // Expense summary functions
    function updateExpenseSummary() {
        if (!allCheckinData || allCheckinData.length === 0) {
            displayNoExpenseData();
            return;
        }
        
        const expenses = calculateMedicationExpenses(allCheckinData);
        
        // Update total expense
        if (totalExpenseAmount) {
            totalExpenseAmount.textContent = `RM ${expenses.total.toFixed(2)}`;
        }
        
        // Calculate average daily expense
        const uniqueDates = [...new Set(allCheckinData.map(entry => entry.date))];
        const avgDaily = uniqueDates.length > 0 ? expenses.total / uniqueDates.length : 0;
        if (avgDailyExpense) {
            avgDailyExpense.textContent = `RM ${avgDaily.toFixed(2)}`;
        }
        
        // Find most expensive medication
        const sortedMedications = Object.entries(expenses.byMedication)
            .sort(([,a], [,b]) => b - a);
        if (mostExpensiveMed) {
            if (sortedMedications.length > 0) {
                const [medName, cost] = sortedMedications[0];
                mostExpensiveMed.textContent = `${medName} (RM ${cost.toFixed(2)})`;
            } else {
                mostExpensiveMed.textContent = '-';
            }
        }
        
        // Update expense breakdown table
        updateExpenseBreakdownTable(expenses.byMedication);
        
        // Update expense chart
        updateExpenseChart(expenses.byMedication);
    }
    
    function displayNoExpenseData() {
        if (totalExpenseAmount) totalExpenseAmount.textContent = 'RM 0.00';
        if (avgDailyExpense) avgDailyExpense.textContent = 'RM 0.00';
        if (mostExpensiveMed) mostExpensiveMed.textContent = '-';
        
        if (expenseBreakdownBody) {
            expenseBreakdownBody.innerHTML = '';
        }
        if (noExpenseDataMessage) {
            noExpenseDataMessage.style.display = 'block';
        }
    }
    
    function updateExpenseBreakdownTable(expensesByMedication) {
        if (!expenseBreakdownBody) return;
        
        if (Object.keys(expensesByMedication).length === 0) {
            expenseBreakdownBody.innerHTML = '';
            if (noExpenseDataMessage) {
                noExpenseDataMessage.style.display = 'block';
            }
            return;
        }
        
        if (noExpenseDataMessage) {
            noExpenseDataMessage.style.display = 'none';
        }
        
        // Calculate usage statistics
        const medicationStats = {};
        allCheckinData.forEach(entry => {
            if (entry.medications && typeof entry.medications === 'object' && !Array.isArray(entry.medications)) {
                // New structure with time periods
                ['morning', 'afternoon', 'evening'].forEach(period => {
                    if (entry.medications[period] && Array.isArray(entry.medications[period])) {
                        entry.medications[period].forEach(med => {
                            const key = med.medication; // Don't include period in key for aggregation
                            if (!medicationStats[key]) {
                                medicationStats[key] = { totalAmount: 0, usageCount: 0, unit: med.unit };
                            }
                            medicationStats[key].totalAmount += parseFloat(med.amount) || 0;
                            medicationStats[key].usageCount += 1;
                        });
                    }
                });
            } else if (entry.medications && Array.isArray(entry.medications)) {
                // Legacy array structure
                entry.medications.forEach(med => {
                    if (!medicationStats[med.medication]) {
                        medicationStats[med.medication] = { totalAmount: 0, usageCount: 0, unit: med.unit };
                    }
                    medicationStats[med.medication].totalAmount += parseFloat(med.amount) || 0;
                    medicationStats[med.medication].usageCount += 1;
                });
            } else if (entry.medication) {
                // Legacy single medication structure
                if (!medicationStats[entry.medication]) {
                    medicationStats[entry.medication] = { totalAmount: 0, usageCount: 0, unit: entry.medicationUnit };
                }
                medicationStats[entry.medication].totalAmount += parseFloat(entry.medicationAmount) || 0;
                medicationStats[entry.medication].usageCount += 1;
            }
        });
        
        const rows = Object.entries(expensesByMedication).map(([medication, totalCost]) => {
            const stats = medicationStats[medication] || { totalAmount: 0, usageCount: 0, unit: '' };
            const unitPrice = getMedicationPrice(medication); // Direct medication name lookup
            const avgCostPerUse = stats.usageCount > 0 ? totalCost / stats.usageCount : 0;
            
            return `
                <tr>
                    <td style="font-weight: 500;">${medication}</td>
                    <td>${stats.totalAmount.toFixed(2)} ${stats.unit}</td>
                    <td>RM ${unitPrice.toFixed(2)}</td>
                    <td style="font-weight: 600; color: #dc3545;">RM ${totalCost.toFixed(2)}</td>
                    <td>${stats.usageCount}</td>
                    <td>RM ${avgCostPerUse.toFixed(2)}</td>
                </tr>
            `;
        }).join('');
        
        expenseBreakdownBody.innerHTML = rows;
    }
    
    function updateExpenseChart(expensesByMedication) {
        if (!expenseChart) return;
        
        const medications = Object.keys(expensesByMedication);
        const expenses = Object.values(expensesByMedication);
        
        if (medications.length === 0) {
            // Destroy existing chart if it exists
            if (window.expenseChartInstance) {
                window.expenseChartInstance.destroy();
                window.expenseChartInstance = null;
            }
            
            // Show no data message
            const ctx = expenseChart.getContext('2d');
            ctx.clearRect(0, 0, expenseChart.width, expenseChart.height);
            ctx.fillStyle = '#6c757d';
            ctx.font = 'bold 18px Arial';
            ctx.textAlign = 'center';
            ctx.fillText('No expense data available', expenseChart.width / 2, expenseChart.height / 2 - 10);
            ctx.font = '14px Arial';
            ctx.fillText('Add medication pricing and check-in data to see charts', expenseChart.width / 2, expenseChart.height / 2 + 15);
            return;
        }
        
        // Generate colors for pie chart
        const colors = medications.map((_, index) => {
            const hue = (index * 360) / medications.length;
            return `hsl(${hue}, 70%, 60%)`;
        });
        
        const chartData = {
            labels: medications.map(med => med.charAt(0).toUpperCase() + med.slice(1)),
            datasets: [{
                data: expenses,
                backgroundColor: colors,
                borderColor: '#fff',
                borderWidth: 2,
                hoverOffset: 4
            }]
        };
        
        const chartOptions = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                title: {
                    display: true,
                    text: 'Medication Expenses Distribution',
                    font: {
                        size: 16,
                        weight: 'bold'
                    },
                    color: '#212529'
                },
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const label = context.label || '';
                            const value = context.parsed;
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = ((value / total) * 100).toFixed(1);
                            return `${label}: RM ${value.toFixed(2)} (${percentage}%)`;
                        }
                    }
                }
            }
        };
        
        // Destroy existing chart if it exists
        if (window.expenseChartInstance) {
            window.expenseChartInstance.destroy();
        }
        
        // Create new pie chart
        window.expenseChartInstance = new Chart(expenseChart, {
            type: 'pie',
            data: chartData,
            options: chartOptions
        });
    }
    
    // Role-based access control functions
    function initializeRoleBasedAccess() {
        // Get user info from auth (this would normally come from login)
        const userInfo = JSON.parse(localStorage.getItem('currentUser') || '{}');
        currentUserRole = userInfo.role || 'MANAGER'; // Default to MANAGER for demo
        currentUserName = userInfo.username || 'Demo User';
        
        // Update UI based on role
        updateUIForRole();
        
        // Display user info
        const userNameEl = document.getElementById('user-name');
        const userRoleEl = document.getElementById('user-role');
        if (userNameEl) userNameEl.textContent = currentUserName;
        if (userRoleEl) {
            userRoleEl.textContent = currentUserRole === 'IT_ADMIN' ? 'IT Admin' : 'Manager';
            userRoleEl.className = `badge ${currentUserRole === 'IT_ADMIN' ? 'bg-primary' : 'bg-success'} ms-2`;
        }
    }
    
    function updateUIForRole() {
        const permissions = ROLE_PERMISSIONS[currentUserRole];
        
        // Hide/show Users Management tab based on permissions
        const usersTabItem = document.getElementById('users-tab-item');
        if (usersTabItem) {
            usersTabItem.style.display = permissions.canManageUsers ? 'block' : 'none';
        }
        
        // Hide/show medication pricing section for managers
        const medicationPricingSection = document.querySelector('.medication-pricing-section');
        if (medicationPricingSection && !permissions.canManagePricing) {
            medicationPricingSection.style.display = 'none';
        }
        
        // Update currency display to RM
        updateCurrencyToRM();
    }
    
    function initializeTabs() {
        // Initialize Bootstrap tabs
        const triggerTabList = [].slice.call(document.querySelectorAll('#adminTabs button'));
        triggerTabList.forEach(function (triggerEl) {
            const tabTrigger = new bootstrap.Tab(triggerEl);
            
            triggerEl.addEventListener('click', function (event) {
                event.preventDefault();
                tabTrigger.show();
            });
        });
    }
    
    function updateCurrencyToRM() {
         // Update all currency displays to RM
         const currencyElements = document.querySelectorAll('.currency, [data-currency]');
         currencyElements.forEach(el => {
             if (el.textContent.includes('$')) {
                 el.textContent = el.textContent.replace('$', 'RM ');
             }
         });
         
         // Update expense summary currency
         const totalExpenseEl = document.getElementById('total-expense-amount');
         const avgDailyExpenseEl = document.getElementById('avg-daily-expense');
         if (totalExpenseEl && totalExpenseEl.textContent.includes('$')) {
             totalExpenseEl.textContent = totalExpenseEl.textContent.replace('$', 'RM ');
         }
         if (avgDailyExpenseEl && avgDailyExpenseEl.textContent.includes('$')) {
             avgDailyExpenseEl.textContent = avgDailyExpenseEl.textContent.replace('$', 'RM ');
         }
     }
     
     function initializeRoleSwitcher() {
         const roleSwitcher = document.getElementById('role-switcher');
         if (roleSwitcher) {
             // Set initial value
             roleSwitcher.value = currentUserRole;
             
             // Handle role changes
             roleSwitcher.addEventListener('change', function() {
                 currentUserRole = this.value;
                 
                 // Update localStorage for persistence
                 const userInfo = JSON.parse(localStorage.getItem('currentUser') || '{}');
                 userInfo.role = currentUserRole;
                 localStorage.setItem('currentUser', JSON.stringify(userInfo));
                 
                 // Update UI
                 updateUIForRole();
                 
                 // Update user role display
                 const userRoleEl = document.getElementById('user-role');
                 if (userRoleEl) {
                     userRoleEl.textContent = currentUserRole === 'IT_ADMIN' ? 'IT Admin' : 'Manager';
                     userRoleEl.className = `badge ${currentUserRole === 'IT_ADMIN' ? 'bg-primary' : 'bg-success'} ms-2`;
                 }
                 
                 // Show notification
                 showRoleChangeNotification();
             });
         }
     }
     
     function showRoleChangeNotification() {
         // Create a temporary notification
         const notification = document.createElement('div');
         notification.className = 'alert alert-info alert-dismissible fade show position-fixed';
         notification.style.cssText = 'top: 20px; right: 20px; z-index: 9999; min-width: 300px;';
         notification.innerHTML = `
             <strong>Role Changed!</strong> You are now viewing as ${currentUserRole === 'IT_ADMIN' ? 'IT Admin' : 'Manager'}.
             <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
         `;
         
         document.body.appendChild(notification);
         
         // Auto-remove after 3 seconds
         setTimeout(() => {
             if (notification.parentNode) {
                 notification.remove();
             }
         }, 3000);
     }
    
    // Make functions global for onclick handlers
    // Language switcher functionality
    function initializeLanguageSwitcher() {
        const languageSwitcher = document.getElementById('languageSwitcher');
        if (!languageSwitcher) return;
        
        // Set initial language display
        updateLanguageDisplay();
        
        // Add event listeners for language options
        const languageOptions = document.querySelectorAll('[data-lang]');
        languageOptions.forEach(option => {
            option.addEventListener('click', function(e) {
                e.preventDefault();
                const selectedLang = this.getAttribute('data-lang');
                translator.setLanguage(selectedLang);
                updateLanguageDisplay();
            });
        });
    }
    
    function updateLanguageDisplay() {
        const currentLang = translator.getCurrentLanguage();
        const languageButton = document.querySelector('#languageSwitcher');
        if (languageButton) {
            const langText = currentLang === 'en' ? 'English' : 'Bahasa Melayu';
            const langSpan = languageButton.querySelector('[data-translate="language"]');
            if (langSpan) {
                langSpan.textContent = translator.t('language');
            }
        }
        
        // Update active state in dropdown
        const languageOptions = document.querySelectorAll('[data-lang]');
        languageOptions.forEach(option => {
            const lang = option.getAttribute('data-lang');
            if (lang === currentLang) {
                option.classList.add('active');
            } else {
                option.classList.remove('active');
            }
        });
    }
    
    // Theme toggle functionality
    function initializeThemeToggle() {
        const themeToggle = document.getElementById('themeToggle');
        const themeIcon = document.getElementById('themeIcon');
        const themeText = document.getElementById('themeText');
        
        if (!themeToggle) {
            // Initialize dark mode from localStorage even if toggle button doesn't exist
            const savedTheme = localStorage.getItem('darkMode');
            const isDarkMode = savedTheme === 'true';
            
            if (isDarkMode) {
                document.body.classList.add('dark-mode');
            }
            return;
        }
        
        // Get saved theme or default to light
        const savedTheme = localStorage.getItem('darkMode');
        const isDarkMode = savedTheme === 'true';
        setTheme(isDarkMode);
        
        // Add click event listener
        themeToggle.addEventListener('click', function() {
            const isDarkMode = document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', isDarkMode);
            setTheme(isDarkMode);
        });
        
        function setTheme(isDarkMode) {
            if (isDarkMode) {
                document.body.classList.add('dark-mode');
                if (themeIcon) themeIcon.className = 'fas fa-sun';
                if (themeText) themeText.textContent = 'Light';
                if (themeToggle) themeToggle.className = 'btn btn-outline-warning btn-sm';
            } else {
                document.body.classList.remove('dark-mode');
                if (themeIcon) themeIcon.className = 'fas fa-moon';
                if (themeText) themeText.textContent = 'Dark';
                if (themeToggle) themeToggle.className = 'btn btn-outline-secondary btn-sm';
            }
        }
    }
    
    window.editWorker = editWorker;
    window.deleteWorker = deleteWorker;
    window.editAdmin = editAdmin;
    window.deleteAdmin = deleteAdmin;
    window.editMedicationPrice = editMedicationPrice;
    window.deleteMedicationPrice = deleteMedicationPrice;
    window.initializeRoleBasedAccess = initializeRoleBasedAccess;
    window.updateUIForRole = updateUIForRole;
    window.initializeLanguageSwitcher = initializeLanguageSwitcher;
});