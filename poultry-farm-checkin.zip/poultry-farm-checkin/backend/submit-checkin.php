<?php
// Set headers to allow cross-origin requests and specify JSON content type
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Only process POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['success' => false, 'message' => 'Only POST requests are allowed']);
    exit;
}

// Get the raw POST data
$rawData = file_get_contents("php://input");
$data = json_decode($rawData, true);

// Validate the data
if (!$data) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Invalid JSON data']);
    exit;
}

// Check required fields
$requiredFields = ['workerName', 'date', 'deadChickens', 'chickenAge', 'weightData', 'medication', 'feedAmount'];
foreach ($requiredFields as $field) {
    if (!isset($data[$field]) || empty($data[$field])) {
        http_response_code(400); // Bad Request
        echo json_encode(['success' => false, 'message' => "Missing required field: {$field}"]);
        exit;
    }
}

// If medication is 'other', check for otherMedication field
if ($data['medication'] === 'other' && (!isset($data['otherMedication']) || empty($data['otherMedication']))) {
    http_response_code(400); // Bad Request
    echo json_encode(['success' => false, 'message' => 'Please specify the other medication']);
    exit;
}

// Add timestamp
$data['timestamp'] = date('Y-m-d H:i:s');

// Create a unique ID for this entry
$data['id'] = uniqid();

// Data storage path
$dataFile = __DIR__ . '/../data/checkins.json';
$dataDir = __DIR__ . '/../data';

// Create data directory if it doesn't exist
if (!file_exists($dataDir)) {
    mkdir($dataDir, 0755, true);
}

// Read existing data
$existingData = [];
if (file_exists($dataFile)) {
    $jsonContent = file_get_contents($dataFile);
    if (!empty($jsonContent)) {
        $existingData = json_decode($jsonContent, true) ?: [];
    }
}

// Add new data
$existingData[] = $data;

// Save data back to file
try {
    file_put_contents($dataFile, json_encode($existingData, JSON_PRETTY_PRINT));
    echo json_encode(['success' => true, 'message' => 'Check-in data saved successfully']);
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Failed to save data: ' . $e->getMessage()]);
}