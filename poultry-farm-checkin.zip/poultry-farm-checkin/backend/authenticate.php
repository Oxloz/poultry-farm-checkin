<?php
// Set headers for JSON response
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode([
        'success' => false,
        'message' => 'Only POST requests are allowed'
    ]);
    exit();
}

// Get JSON input
$json = file_get_contents('php://input');
$data = json_decode($json, true);

// Validate input
if (!isset($data['username']) || !isset($data['password'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Username and password are required'
    ]);
    exit();
}

// Get user credentials
$username = $data['username'];
$password = $data['password'];
$requestedRole = isset($data['role']) ? $data['role'] : 'worker';

// Load users from JSON file
$usersFile = '../data/users.json';

if (!file_exists($usersFile)) {
    echo json_encode([
        'success' => false,
        'message' => 'User database not found'
    ]);
    exit();
}

$usersData = json_decode(file_get_contents($usersFile), true);

if (!isset($usersData['users']) || !is_array($usersData['users'])) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid user database format'
    ]);
    exit();
}

// Find user
$authenticated = false;
$user = null;

foreach ($usersData['users'] as $userData) {
    if ($userData['username'] === $username && $userData['password'] === $password) {
        $authenticated = true;
        $user = $userData;
        break;
    }
}

// Check if user was found
if (!$authenticated || !$user) {
    echo json_encode([
        'success' => false,
        'message' => 'Invalid username or password'
    ]);
    exit();
}

// Check if user has the requested role
if ($requestedRole === 'admin' && $user['role'] !== 'admin') {
    echo json_encode([
        'success' => false,
        'message' => 'You do not have admin privileges'
    ]);
    exit();
}

// Remove password from user data before sending to client
unset($user['password']);

// Return success response with user data
echo json_encode([
    'success' => true,
    'message' => 'Authentication successful',
    'user' => $user
]);