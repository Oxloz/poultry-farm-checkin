<?php
// Set headers to allow cross-origin requests and specify JSON content type
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");
header("Content-Type: application/json");

// Only process GET requests
if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405); // Method Not Allowed
    echo json_encode(['success' => false, 'message' => 'Only GET requests are allowed']);
    exit;
}

// Data storage path
$dataFile = __DIR__ . '/../data/checkins.json';

// Check if data file exists
if (!file_exists($dataFile)) {
    echo json_encode(['success' => true, 'data' => []]);
    exit;
}

// Read data from file
try {
    $jsonContent = file_get_contents($dataFile);
    $data = json_decode($jsonContent, true);
    
    if ($data === null && json_last_error() !== JSON_ERROR_NONE) {
        throw new Exception('Invalid JSON data: ' . json_last_error_msg());
    }
    
    // Sort data by date (newest first)
    usort($data, function($a, $b) {
        return strtotime($b['date']) - strtotime($a['date']);
    });
    
    echo json_encode(['success' => true, 'data' => $data]);
} catch (Exception $e) {
    http_response_code(500); // Internal Server Error
    echo json_encode(['success' => false, 'message' => 'Failed to retrieve data: ' . $e->getMessage()]);
}