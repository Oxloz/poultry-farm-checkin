// Translation dictionary for English and Malay
const translations = {
    en: {
        // Navigation and Headers
        'dashboard': 'Dashboard',
        'users_management': 'Users Management',
        'admin_dashboard': 'Admin Dashboard',
        'welcome': 'Welcome to the Poultry Farm Management System',
        'role': 'Role',
        'language': 'Language',
        
        // Role switcher
        'select_role': 'Select Role',
        'manager': 'Manager',
        'it_admin': 'IT Admin',
        
        // Language switcher
        'select_language': 'Select Language',
        'english': 'English',
        'bahasa_melayu': 'Bahasa Melayu',
        
        // Dashboard Statistics
        'total_checkins': 'Total Check-ins',
        'total_chicken_count': 'Total Chicken Count',
        'latest_weight_entry': 'Latest Weight Entry',
        'dead_chickens': 'Dead Chickens',
        'medication_uses': 'Medication Uses',
        'avg_chicken_weight': 'Average Chicken Weight',
        'total_feed': 'Total Feed',
        'avg_chicken_age': 'Average Chicken Age',
        'kg': 'kg',
        
        // Worker Management
        'worker_management': 'Worker Management',
        'add_new_worker': 'Add New Worker',
        'worker_name': 'Worker Name',
        'worker_password': 'Worker Password',
        'add_worker': 'Add Worker',
        'current_workers': 'Current Workers',
        'existing_workers': 'Existing Workers',
        'name': 'Name',
        'full_name': 'Full Name',
        'password': 'Password',
        'actions': 'Actions',
        'delete': 'Delete',
        'no_workers_found': 'No workers found.',
        'no_workers_created': 'No workers have been created yet.',
        
        // Admin Management
        'admin_credentials': 'Admin Credentials',
        'credentials_management': 'Credentials Management',
        'update_admin_details': 'Update Admin Details',
        'admin_username': 'Admin Username',
        'admin_password': 'Admin Password',
        'update_admin': 'Update Admin',
        'current_admin_accounts': 'Current Admin Accounts',
        'username': 'Username',
        'no_admin_accounts_found': 'No admin accounts found.',
        'no_admin_accounts': 'No admin accounts found.',
        
        // Medication Pricing
        'medication_pricing': 'Medication Pricing',
        'medication_pricing_management': 'Medication Pricing Management',
        'set_manage_pricing': 'Set and manage pricing for medications to track expenses.',
        'add_update_medication_price': 'Add/Update Medication Price',
        'medication_name': 'Medication Name',
        'select_medication': 'Select Medication',
        'price_per_unit': 'Price per Unit (RM)',
        'price_per_unit_rm': 'Price per Unit (RM)',
        'unit_type': 'Unit Type',
        'add_update_price': 'Add/Update Price',
        'save_price': 'Save Price',
        'clear_form': 'Clear Form',
        'current_medication_prices': 'Current Medication Prices',
        'price': 'Price',
        'no_medication_prices_found': 'No medication prices found.',
        'no_medication_prices': 'No medication prices found.',
        'total_medication_expenses': 'Total Medication Expenses',
        'average_daily_cost': 'Average Daily Cost',
        'most_expensive_medication': 'Most Expensive Medication',
        
        // Charts and Analytics
        'daily_expenses': 'Daily Expenses',
        'total_expenses': 'Total Expenses',
        'average_daily_expense': 'Average Daily Expense',
        'medication_expenses_by_type': 'Medication Expenses by Type (RM)',
        'no_expense_data_available': 'No expense data available',
        'add_medication_pricing_data': 'Add medication pricing and check-in data to see charts',
        
        // Buttons and Actions
        'save': 'Save',
        'cancel': 'Cancel',
        'edit': 'Edit',
        'confirm': 'Confirm',
        'close': 'Close',
        
        // Messages
        'success': 'Success',
        'error': 'Error',
        'warning': 'Warning',
        'info': 'Information',
        'loading': 'Loading...',
        'please_wait': 'Please wait...',
        
        // Role Switcher
        'switch_role': 'Switch Role (Demo)',
        'manager': 'Manager',
        'it_admin': 'IT Admin',
        'role_changed_to': 'Role changed to',
        
        // Form Validation
        'required_field': 'This field is required',
        'invalid_input': 'Invalid input',
        'password_too_short': 'Password must be at least 6 characters',
        'username_exists': 'Username already exists',
        
        // Time and Date
        'today': 'Today',
        'yesterday': 'Yesterday',
        'this_week': 'This Week',
        'this_month': 'This Month',
        'last_updated': 'Last Updated',
        
        // Check-in page translations
        'checkin_title': 'Poultry Farm Daily Check-in',
        'welcome_text': 'Welcome',
        'logout': 'Logout',
        'form_title': 'Daily Check-in Form',
        'worker_name_field': 'Worker Name',
        'date_field': 'Date',
        'dead_chickens_field': 'Number of Dead Chickens',
        'chicken_tracking': 'Chicken Age and Weight Tracking',
        'chicken_age': 'Chicken Age (weeks)',
        'daily_weight': 'Daily Weight Measurement',
        'combined_weight': 'Combined Weight (kg)',
        'separated_weight': 'Separated Weight Measurement',
        'male_weight': 'Male Chickens Weight (kg)',
        'female_weight': 'Female Chickens Weight (kg)',
        'medication_management': 'Medication Management',
        'morning': 'Morning',
        'afternoon': 'Afternoon',
        'evening': 'Evening',
        'add_medication': 'Add Medication',
        'medication': 'Medication',
        'amount': 'Amount',
        'unit': 'Unit',
        'other': 'Other',
        'remove': 'Remove',
        'feed_consumption': 'Feed Consumption (kg)',
        'notes': 'Additional Notes',
        'submit': 'Submit Check-in',
        'success_message': 'Check-in submitted successfully!',
        'error_message': 'Error submitting check-in. Please try again.'
    },
    
    ms: {
        // Navigation and Headers
        'dashboard': 'Papan Pemuka',
        'users_management': 'Pengurusan Pengguna',
        'admin_dashboard': 'Papan Pemuka Pentadbir',
        'welcome': 'Selamat datang ke Sistem Pengurusan Ladang Ayam',
        'role': 'Peranan',
        'language': 'Bahasa',
        
        // Role switcher
        'select_role': 'Pilih Peranan',
        'manager': 'Pengurus',
        'it_admin': 'Pentadbir IT',
        
        // Language switcher
        'select_language': 'Pilih Bahasa',
        'english': 'Bahasa Inggeris',
        'bahasa_melayu': 'Bahasa Melayu',
        
        // Dashboard Statistics
        'total_checkins': 'Jumlah Daftar Masuk',
        'total_chicken_count': 'Jumlah Ayam Keseluruhan',
        'latest_weight_entry': 'Entri Berat Terkini',
        'dead_chickens': 'Ayam Mati',
        'medication_uses': 'Penggunaan Ubat',
        'avg_chicken_weight': 'Purata Berat Ayam',
        'total_feed': 'Jumlah Makanan',
        'avg_chicken_age': 'Purata Umur Ayam',
        'kg': 'kg',
        
        // Worker Management
        'worker_management': 'Pengurusan Pekerja',
        'add_new_worker': 'Tambah Pekerja Baru',
        'worker_name': 'Nama Pekerja',
        'worker_password': 'Kata Laluan Pekerja',
        'add_worker': 'Tambah Pekerja',
        'current_workers': 'Pekerja Semasa',
        'existing_workers': 'Pekerja Sedia Ada',
        'name': 'Nama',
        'full_name': 'Nama Penuh',
        'password': 'Kata Laluan',
        'actions': 'Tindakan',
        'delete': 'Padam',
        'no_workers_found': 'Tiada pekerja dijumpai.',
        'no_workers_created': 'Tiada pekerja telah dicipta lagi.',
        
        // Admin Management
        'admin_credentials': 'Kelayakan Admin',
        'credentials_management': 'Pengurusan Kelayakan',
        'update_admin_details': 'Kemas Kini Butiran Admin',
        'admin_username': 'Nama Pengguna Admin',
        'admin_password': 'Kata Laluan Admin',
        'update_admin': 'Kemas Kini Admin',
        'current_admin_accounts': 'Akaun Admin Semasa',
        'username': 'Nama Pengguna',
        'no_admin_accounts_found': 'Tiada akaun admin dijumpai.',
        'no_admin_accounts': 'Tiada akaun admin dijumpai.',
        
        // Medication Pricing
        'medication_pricing': 'Harga Ubat',
        'medication_pricing_management': 'Pengurusan Harga Ubat',
        'set_manage_pricing': 'Tetapkan dan urus harga ubat untuk menjejaki perbelanjaan.',
        'add_update_medication_price': 'Tambah/Kemas Kini Harga Ubat',
        'medication_name': 'Nama Ubat',
        'select_medication': 'Pilih Ubat',
        'price_per_unit': 'Harga Seunit (RM)',
        'price_per_unit_rm': 'Harga Seunit (RM)',
        'unit_type': 'Jenis Unit',
        'add_update_price': 'Tambah/Kemas Kini Harga',
        'save_price': 'Simpan Harga',
        'clear_form': 'Kosongkan Borang',
        'current_medication_prices': 'Harga Ubat Semasa',
        'price': 'Harga',
        'no_medication_prices_found': 'Tiada harga ubat dijumpai.',
        'no_medication_prices': 'Tiada harga ubat dijumpai.',
        'total_medication_expenses': 'Jumlah Perbelanjaan Ubat',
        'average_daily_cost': 'Purata Kos Harian',
        'most_expensive_medication': 'Ubat Paling Mahal',
        
        // Charts and Analytics
        'daily_expenses': 'Perbelanjaan Harian',
        'total_expenses': 'Jumlah Perbelanjaan',
        'average_daily_expense': 'Purata Perbelanjaan Harian',
        'medication_expenses_by_type': 'Perbelanjaan Ubat Mengikut Jenis (RM)',
        'no_expense_data_available': 'Tiada data perbelanjaan tersedia',
        'add_medication_pricing_data': 'Tambah harga ubat dan data daftar masuk untuk melihat carta',
        
        // Buttons and Actions
        'save': 'Simpan',
        'cancel': 'Batal',
        'edit': 'Edit',
        'confirm': 'Sahkan',
        'close': 'Tutup',
        
        // Messages
        'success': 'Berjaya',
        'error': 'Ralat',
        'warning': 'Amaran',
        'info': 'Maklumat',
        'loading': 'Memuatkan...',
        'please_wait': 'Sila tunggu...',
        
        // Role Switcher
        'switch_role': 'Tukar Peranan (Demo)',
        'manager': 'Pengurus',
        'it_admin': 'Admin IT',
        'role_changed_to': 'Peranan ditukar kepada',
        
        // Form Validation
        'required_field': 'Medan ini diperlukan',
        'invalid_input': 'Input tidak sah',
        'password_too_short': 'Kata laluan mestilah sekurang-kurangnya 6 aksara',
        'username_exists': 'Nama pengguna sudah wujud',
        
        // Time and Date
        'today': 'Hari Ini',
        'yesterday': 'Semalam',
        'this_week': 'Minggu Ini',
        'this_month': 'Bulan Ini',
        'last_updated': 'Terakhir Dikemas Kini',
        
        // Check-in page translations
        'checkin_title': 'Daftar Masuk Harian Ladang Ayam',
        'welcome_text': 'Selamat Datang',
        'logout': 'Log Keluar',
        'form_title': 'Borang Daftar Masuk Harian',
        'worker_name_field': 'Nama Pekerja',
        'date_field': 'Tarikh',
        'dead_chickens_field': 'Bilangan Ayam Mati',
        'chicken_tracking': 'Penjejakan Umur dan Berat Ayam',
        'chicken_age': 'Umur Ayam (minggu)',
        'daily_weight': 'Pengukuran Berat Harian',
        'combined_weight': 'Berat Gabungan (kg)',
        'separated_weight': 'Pengukuran Berat Terpisah',
        'male_weight': 'Berat Ayam Jantan (kg)',
        'female_weight': 'Berat Ayam Betina (kg)',
        'medication_management': 'Pengurusan Ubat',
        'morning': 'Pagi',
        'afternoon': 'Petang',
        'evening': 'Malam',
        'add_medication': 'Tambah Ubat',
        'medication': 'Ubat',
        'amount': 'Jumlah',
        'unit': 'Unit',
        'other': 'Lain-lain',
        'remove': 'Buang',
        'feed_consumption': 'Penggunaan Makanan (kg)',
        'notes': 'Nota Tambahan',
        'submit': 'Hantar Daftar Masuk',
        'success_message': 'Daftar masuk berjaya dihantar!',
        'error_message': 'Ralat menghantar daftar masuk. Sila cuba lagi.'
    },
    
    zh: {
        // Navigation and Headers
        'dashboard': '仪表板',
        'users_management': '用户管理',
        'admin_dashboard': '管理员仪表板',
        'welcome': '欢迎使用家禽农场管理系统',
        'role': '角色',
        'language': '语言',
        
        // Role switcher
        'select_role': '选择角色',
        'manager': '经理',
        'it_admin': 'IT管理员',
        
        // Language switcher
        'select_language': '选择语言',
        'english': '英语',
        'bahasa_melayu': '马来语',
        'chinese': '中文',
        
        // Dashboard Statistics
        'total_checkins': '总签到次数',
        'total_chicken_count': '鸡只总数',
        'latest_weight_entry': '最新体重记录',
        'dead_chickens': '死鸡数量',
        'medication_uses': '药物使用',
        'avg_chicken_weight': '平均鸡只体重',
        'total_feed': '总饲料',
        'avg_chicken_age': '平均鸡龄',
        'kg': '公斤',
        
        // Worker Management
        'worker_management': '工人管理',
        'add_new_worker': '添加新工人',
        'worker_name': '工人姓名',
        'worker_password': '工人密码',
        'add_worker': '添加工人',
        'current_workers': '当前工人',
        'existing_workers': '现有工人',
        'name': '姓名',
        'full_name': '全名',
        'password': '密码',
        'actions': '操作',
        'delete': '删除',
        'no_workers_found': '未找到工人。',
        'no_workers_created': '尚未创建工人。',
        
        // Admin Management
        'admin_credentials': '管理员凭据',
        'credentials_management': '凭据管理',
        'update_admin_details': '更新管理员详情',
        'admin_username': '管理员用户名',
        'admin_password': '管理员密码',
        'update_admin': '更新管理员',
        'current_admin_accounts': '当前管理员账户',
        'username': '用户名',
        'no_admin_accounts_found': '未找到管理员账户。',
        'no_admin_accounts': '未找到管理员账户。',
        
        // Medication Pricing
        'medication_pricing': '药物定价',
        'medication_pricing_management': '药物定价管理',
        'set_manage_pricing': '设置和管理药物价格以跟踪费用。',
        'add_update_medication_price': '添加/更新药物价格',
        'medication_name': '药物名称',
        'select_medication': '选择药物',
        'price_per_unit': '单价 (RM)',
        'price_per_unit_rm': '单价 (RM)',
        'unit_type': '单位类型',
        'add_update_price': '添加/更新价格',
        'save_price': '保存价格',
        'clear_form': '清除表单',
        'current_medication_prices': '当前药物价格',
        'price': '价格',
        'no_medication_prices_found': '未找到药物价格。',
        'no_medication_prices': '未找到药物价格。',
        'total_medication_expenses': '药物总费用',
        'average_daily_cost': '平均每日费用',
        'most_expensive_medication': '最昂贵的药物',
        
        // Expense Analytics
        'daily_expenses': '每日支出',
        'total_expenses': '总支出',
        'average_daily_expense': '平均每日支出',
        'medication_expenses_by_type': '按类型分类的药物支出 (RM)',
        'no_expense_data_available': '无支出数据',
        'add_medication_pricing_data': '添加药物定价和签到数据以查看图表',
        
        // Common Actions
        'save': '保存',
        'cancel': '取消',
        'edit': '编辑',
        'confirm': '确认',
        'close': '关闭',
        
        // Status Messages
        'success': '成功',
        'error': '错误',
        'warning': '警告',
        'info': '信息',
        'loading': '加载中...',
        'please_wait': '请稍候...',
        
        // Role Demo
        'switch_role': '切换角色 (演示)',
        'manager': '经理',
        'it_admin': 'IT管理员',
        'role_changed_to': '角色已更改为',
        
        // Validation Messages
        'required_field': '此字段为必填项',
        'invalid_input': '无效输入',
        'password_too_short': '密码至少需要6个字符',
        'username_exists': '用户名已存在',
        
        // Time References
        'today': '今天',
        'yesterday': '昨天',
        'this_week': '本周',
        'this_month': '本月',
        'last_updated': '最后更新',
        
        // Check-in page translations
        'checkin_title': '家禽农场每日签到',
        'welcome_text': '欢迎',
        'logout': '登出',
        'form_title': '每日签到表单',
        'worker_name_field': '工人姓名',
        'date_field': '日期',
        'dead_chickens_field': '死鸡数量',
        'chicken_tracking': '鸡龄和体重跟踪',
        'chicken_age': '鸡龄（周）',
        'daily_weight': '每日体重测量',
        'combined_weight': '综合体重（公斤）',
        'separated_weight': '分离体重测量',
        'male_weight': '公鸡体重（公斤）',
        'female_weight': '母鸡体重（公斤）',
        'medication_management': '药物管理',
        'morning': '上午',
        'afternoon': '下午',
        'evening': '晚上',
        'add_medication': '添加药物',
        'medication': '药物',
        'amount': '数量',
        'unit': '单位',
        'other': '其他',
        'remove': '移除',
        'feed_consumption': '饲料消耗（公斤）',
        'notes': '附加说明',
        'submit': '提交签到',
        'success_message': '签到提交成功！',
        'error_message': '提交签到时出错。请重试。'
    }
};

// Translation utility functions
class TranslationManager {
    constructor() {
        this.currentLanguage = localStorage.getItem('preferred_language') || 'en';
        this.translations = translations;
    }
    
    // Get translation for a key
    t(key) {
        return this.translations[this.currentLanguage][key] || this.translations['en'][key] || key;
    }
    
    // Set current language
    setLanguage(lang) {
        if (this.translations[lang]) {
            this.currentLanguage = lang;
            localStorage.setItem('preferred_language', lang);
            this.updateAllTranslations();
            this.showLanguageChangeNotification(lang);
        }
    }
    
    // Get current language
    getCurrentLanguage() {
        return this.currentLanguage;
    }
    
    // Update all elements with data-translate attribute
    updateAllTranslations() {
        const elements = document.querySelectorAll('[data-translate]');
        elements.forEach(element => {
            const key = element.getAttribute('data-translate');
            const translation = this.t(key);
            
            if (element.tagName === 'INPUT' && (element.type === 'text' || element.type === 'password')) {
                element.placeholder = translation;
            } else {
                element.textContent = translation;
            }
        });
        
        // Update chart if it exists
        if (typeof updateExpenseChart === 'function' && window.currentExpenseData) {
            updateExpenseChart(window.currentExpenseData);
        }
    }
    
    // Show language change notification
    showLanguageChangeNotification(lang) {
        const langName = lang === 'en' ? 'English' : 'Bahasa Melayu';
        const message = `${this.t('language')} ${this.t('role_changed_to').toLowerCase()} ${langName}`;
        
        // Create notification element
        const notification = document.createElement('div');
        notification.className = 'alert alert-info position-fixed';
        notification.style.cssText = `
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 250px;
            animation: slideInRight 0.3s ease-out;
        `;
        notification.innerHTML = `
            <i class="fas fa-language me-2"></i>
            ${message}
        `;
        
        document.body.appendChild(notification);
        
        // Remove notification after 3 seconds
        setTimeout(() => {
            notification.style.animation = 'slideOutRight 0.3s ease-in';
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 300);
        }, 3000);
    }
}

// Global translation manager instance
const translator = new TranslationManager();

// Helper function for easy access
function t(key) {
    return translator.t(key);
}

// CSS animations for notifications
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutRight {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);