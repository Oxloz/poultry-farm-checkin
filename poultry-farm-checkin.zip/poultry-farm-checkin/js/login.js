// Login page JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Language translations
    const translations = {
        en: {
            title: 'Poultry Farm Check-in',
            subtitle: 'Please log in to continue',
            worker: 'Worker',
            admin: 'Admin',
            username: 'Username',
            password: 'Password',
            login: 'Log In',
            invalidCredentials: 'Invalid username or password. Please try again.',
            authFailed: 'Authentication failed. Please try again.',
            enterBoth: 'Please enter both username and password',
            noAdminPrivileges: 'You do not have admin privileges'
        },
        es: {
            title: 'Check-in de Granja Avícola',
            subtitle: 'Por favor inicie sesión para continuar',
            worker: 'Trabajador',
            admin: 'Administrador',
            username: 'Usuario',
            password: 'Contraseña',
            login: 'Iniciar Sesión',
            invalidCredentials: 'Usuario o contraseña inválidos. Inténtelo de nuevo.',
            authFailed: 'Autenticación fallida. Inténtelo de nuevo.',
            enterBoth: 'Por favor ingrese usuario y contraseña',
            noAdminPrivileges: 'No tiene privilegios de administrador'
        },
        fr: {
            title: 'Enregistrement Ferme Avicole',
            subtitle: 'Veuillez vous connecter pour continuer',
            worker: 'Ouvrier',
            admin: 'Administrateur',
            username: 'Nom d\'utilisateur',
            password: 'Mot de passe',
            login: 'Se connecter',
            invalidCredentials: 'Nom d\'utilisateur ou mot de passe invalide. Veuillez réessayer.',
            authFailed: 'Échec de l\'authentification. Veuillez réessayer.',
            enterBoth: 'Veuillez saisir le nom d\'utilisateur et le mot de passe',
            noAdminPrivileges: 'Vous n\'avez pas les privilèges d\'administrateur'
        },
        zh: {
            title: '家禽农场签到',
            subtitle: '请登录以继续',
            worker: '工人',
            admin: '管理员',
            username: '用户名',
            password: '密码',
            login: '登录',
            invalidCredentials: '用户名或密码无效。请重试。',
            authFailed: '认证失败。请重试。',
            enterBoth: '请输入用户名和密码',
            noAdminPrivileges: '您没有管理员权限'
        }
    };

    // Elements
    const loginForm = document.getElementById('login-form');
    const loginError = document.getElementById('login-error');
    const workerRoleBtn = document.getElementById('worker-role');
    const adminRoleBtn = document.getElementById('admin-role');
    const themeToggle = document.getElementById('theme-toggle');
    const languageSelect = document.getElementById('language-select');
    
    // Initialize theme and language
    initializeTheme();
    initializeLanguage();
    
    // Set default role
    let selectedRole = 'worker';
    
    // Event listeners for role selection
    workerRoleBtn.addEventListener('click', function() {
        selectedRole = 'worker';
        workerRoleBtn.classList.add('active');
        adminRoleBtn.classList.remove('active');
    });
    
    adminRoleBtn.addEventListener('click', function() {
        selectedRole = 'admin';
        adminRoleBtn.classList.add('active');
        workerRoleBtn.classList.remove('active');
    });
    
    // Handle form submission
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value.trim();
        
        // Validate inputs
        if (!username || !password) {
            showErrorTranslated('enterBoth');
            return;
        }
        
        // Authenticate user
        authenticateUser(username, password, selectedRole);
    });
    
    // Theme toggle event listener
    themeToggle.addEventListener('click', function() {
        const isDarkMode = document.body.classList.toggle('dark-mode');
        localStorage.setItem('darkMode', isDarkMode);
        updateThemeToggleText(isDarkMode);
    });
    
    // Language selection event listener
    languageSelect.addEventListener('change', function() {
        const selectedLanguage = this.value;
        localStorage.setItem('selectedLanguage', selectedLanguage);
        updatePageLanguage(selectedLanguage);
    });
    
    // Authentication function
    function authenticateUser(username, password, role) {
        // Get default accounts from localStorage or set defaults
        const defaultWorkerAccounts = JSON.parse(localStorage.getItem('defaultWorkerAccounts')) || [
            { username: 'worker1', password: 'pass123' },
            { username: 'worker2', password: 'pass456' }
        ];
        
        const defaultAdminAccounts = JSON.parse(localStorage.getItem('defaultAdminAccounts')) || [
            { username: 'admin', password: 'admin123' },
            { username: 'Jabez', password: 'pass' }
        ];
        
        // Store defaults if not already stored
        if (!localStorage.getItem('defaultWorkerAccounts')) {
            localStorage.setItem('defaultWorkerAccounts', JSON.stringify(defaultWorkerAccounts));
        }
        if (!localStorage.getItem('defaultAdminAccounts')) {
            localStorage.setItem('defaultAdminAccounts', JSON.stringify(defaultAdminAccounts));
        }
        
        // Combine all user data
        const allUsers = [
            ...defaultWorkerAccounts.map(user => ({ ...user, role: 'worker' })),
            ...defaultAdminAccounts.map(user => ({ ...user, role: 'admin' }))
        ];
        
        // Find matching user
        const user = allUsers.find(u => u.username === username && u.password === password);
        
        if (user) {
            if (role === 'admin' && user.role !== 'admin') {
                showErrorTranslated('noAdminPrivileges');
                return;
            }
            
            // Store user session
            sessionStorage.setItem('currentUser', JSON.stringify({
                username: user.username,
                role: user.role,
                loginTime: new Date().toISOString()
            }));
            
            // Redirect based on role
            if (user.role === 'admin') {
                window.location.href = 'admin/admin-dashboard.html';
            } else {
                window.location.href = 'index.html';
            }
        } else {
            showErrorTranslated('invalidCredentials');
        }
    }
    
    // Check if user is already logged in
    function checkLoggedInStatus() {
        const currentUser = sessionStorage.getItem('currentUser');
        if (currentUser) {
            const user = JSON.parse(currentUser);
            if (user.role === 'admin') {
                window.location.href = 'admin/admin-dashboard.html';
            } else {
                window.location.href = 'index.html';
            }
        }
    }
    
    // Initialize theme
    function initializeTheme() {
        const savedTheme = localStorage.getItem('darkMode');
        const isDarkMode = savedTheme === 'true';
        
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
        }
        
        updateThemeToggleText(isDarkMode);
    }
    
    // Update theme toggle text
    function updateThemeToggleText(isDarkMode) {
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.textContent = isDarkMode ? '☀️' : '🌙';
        }
    }
    
    // Initialize language
    function initializeLanguage() {
        const savedLanguage = localStorage.getItem('selectedLanguage') || 'en';
        languageSelect.value = savedLanguage;
        updatePageLanguage(savedLanguage);
    }
    
    // Update page language
    function updatePageLanguage(language) {
        const t = translations[language] || translations.en;
        
        // Update page title
        document.title = t.title;
        
        // Update header
        document.querySelector('.login-header h1').textContent = t.title;
        document.querySelector('.login-header p').textContent = t.subtitle;
        
        // Update role buttons
        document.getElementById('worker-role').textContent = t.worker;
        document.getElementById('admin-role').textContent = t.admin;
        
        // Update form labels
        document.querySelector('label[for="username"]').textContent = t.username;
        document.querySelector('label[for="password"]').textContent = t.password;
        
        // Update login button
        document.querySelector('button[type="submit"]').textContent = t.login;
    }
    
    // Show translated error message
    function showErrorTranslated(errorKey) {
        const currentLanguage = languageSelect.value || 'en';
        const t = translations[currentLanguage] || translations.en;
        const errorMessage = t[errorKey] || t.authFailed;
        
        loginError.textContent = errorMessage;
        loginError.classList.remove('d-none');
        
        // Hide error after 5 seconds
        setTimeout(() => {
            loginError.classList.add('d-none');
        }, 5000);
    }
    
    // Check logged in status on page load
    checkLoggedInStatus();
});