// Admin Authentication Script

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in and has admin role
    const userData = JSON.parse(sessionStorage.getItem('userData'));
    
    // If no user data or not admin role, redirect to login page
    if (!userData || userData.role !== 'admin') {
        window.location.href = '../standalone-login.html';
        return;
    }
    
    // Display user name in the header
    const userNameElement = document.getElementById('user-name');
    if (userNameElement) {
        userNameElement.textContent = `Welcome, ${userData.name}`;
    }
    
    // Handle logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            // Clear session storage
            sessionStorage.removeItem('userData');
            // Redirect to login page
            window.location.href = '../standalone-login.html';
        });
    }
});