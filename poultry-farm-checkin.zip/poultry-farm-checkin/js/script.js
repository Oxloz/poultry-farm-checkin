// Poultry Farm Check-in Tool JavaScript

document.addEventListener('DOMContentLoaded', function() {
    // Initialize dark mode
    initializeDarkMode();
    
    // Initialize language
    initializeLanguage();
    
    // Theme toggle event listener
    const themeToggle = document.getElementById('theme-toggle');
    if (themeToggle) {
        themeToggle.addEventListener('click', function() {
            const isDarkMode = document.body.classList.toggle('dark-mode');
            localStorage.setItem('darkMode', isDarkMode);
            updateThemeToggleText(isDarkMode);
        });
    }
    
    // Language selection event listener
    const languageSelect = document.getElementById('language-select');
    if (languageSelect) {
        languageSelect.addEventListener('change', function() {
            const selectedLanguage = this.value;
            localStorage.setItem('selectedLanguage', selectedLanguage);
            updatePageLanguage(selectedLanguage);
        });
    }
    
    // Check if user is logged in
    const userData = JSON.parse(sessionStorage.getItem('userData'));
    
    // If no user data, redirect to login page
    if (!userData || (userData.role !== 'worker' && userData.role !== 'admin')) {
        window.location.href = 'login.html';
        return;
    }
    
    // Display user name in the header
    const userNameElement = document.getElementById('user-name');
    if (userNameElement) {
        userNameElement.textContent = `Welcome, ${userData.name}`;
    }
    
    // Handle logout button
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            // Clear session storage
            sessionStorage.removeItem('userData');
            // Redirect to login page
            window.location.href = 'login.html';
        });
    }
    // Set default date to today
    document.getElementById('date').valueAsDate = new Date();
    
    // Set worker name from session data
    const workerNameField = document.getElementById('workerName');
    if (workerNameField && userData) {
        workerNameField.value = userData.name;
    }
    
    // Enhanced Medication Management System
    let medicationCounter = 0;
    
    // Initialize medication management
    initializeMedicationManagement();
    
    // Initialize chicken age and weight tracking
    initializeChickenTracking();
    
    function initializeMedicationManagement() {
        // Add event listeners for "Add Medication" buttons
        const addMedicationBtns = document.querySelectorAll('.add-medication-btn');
        addMedicationBtns.forEach(btn => {
            btn.addEventListener('click', function() {
                const period = this.getAttribute('data-period');
                addMedicationEntry(period);
            });
        });
    }
    
    function addMedicationEntry(period) {
        const template = document.getElementById('medication-entry-template');
        const medicationsList = document.getElementById(`${period}-medications`);
        
        // Clone the template
        const newEntry = template.cloneNode(true);
        newEntry.id = `medication-entry-${period}-${medicationCounter++}`;
        newEntry.classList.remove('d-none');
        
        // Add event listeners to the new entry
        setupMedicationEntryListeners(newEntry, period);
        
        // Append to the medications list
        medicationsList.appendChild(newEntry);
        
        // Focus on the medication select
        const medicationSelect = newEntry.querySelector('.medication-select');
        medicationSelect.focus();
    }
    
    function setupMedicationEntryListeners(entry, period) {
        // Handle medication selection change
        const medicationSelect = entry.querySelector('.medication-select');
        const otherMedicationRow = entry.querySelector('.other-medication-row');
        const otherMedicationInput = entry.querySelector('.other-medication-input');
        
        medicationSelect.addEventListener('change', function() {
            if (this.value === 'other') {
                otherMedicationRow.classList.remove('d-none');
                otherMedicationInput.setAttribute('required', 'required');
            } else {
                otherMedicationRow.classList.add('d-none');
                otherMedicationInput.removeAttribute('required');
                otherMedicationInput.value = '';
            }
        });
        
        // Handle remove button
        const removeBtn = entry.querySelector('.remove-medication-btn');
        removeBtn.addEventListener('click', function() {
            entry.remove();
        });
     }
     
     // Initialize chicken age and weight tracking functionality
     function initializeChickenTracking() {
         const chickenAgeInput = document.getElementById('chickenAge');
         const combinedWeightSection = document.getElementById('combined-weight-section');
         const separatedWeightSection = document.getElementById('separated-weight-section');
         
         // Add event listener for chicken age changes
         chickenAgeInput.addEventListener('input', function() {
             const age = parseInt(this.value);
             toggleWeightSections(age);
         });
         
         // Initial check on page load
         const initialAge = parseInt(chickenAgeInput.value);
         if (initialAge) {
             toggleWeightSections(initialAge);
         }
     }
     
     function toggleWeightSections(age) {
         const combinedWeightSection = document.getElementById('combined-weight-section');
         const separatedWeightSection = document.getElementById('separated-weight-section');
         const totalWeightInput = document.getElementById('totalWeight');
         const chickenCountInput = document.getElementById('chickenCount');
         const maleWeightInput = document.getElementById('maleWeight');
         const maleCountInput = document.getElementById('maleCount');
         const femaleWeightInput = document.getElementById('femaleWeight');
         const femaleCountInput = document.getElementById('femaleCount');
         
         if (age >= 18) {
             // Show separated weight section for chickens 18+ days old
             combinedWeightSection.classList.add('d-none');
             separatedWeightSection.classList.remove('d-none');
             
             // Remove required attribute from combined weight fields
             totalWeightInput.removeAttribute('required');
             chickenCountInput.removeAttribute('required');
             
             // Add required attribute to separated weight fields
             maleWeightInput.setAttribute('required', 'required');
             maleCountInput.setAttribute('required', 'required');
             femaleWeightInput.setAttribute('required', 'required');
             femaleCountInput.setAttribute('required', 'required');
             
             // Clear combined weight values
             totalWeightInput.value = '';
             chickenCountInput.value = '';
         } else {
             // Show combined weight section for chickens under 18 days
             combinedWeightSection.classList.remove('d-none');
             separatedWeightSection.classList.add('d-none');
             
             // Add required attribute to combined weight fields
             totalWeightInput.setAttribute('required', 'required');
             chickenCountInput.setAttribute('required', 'required');
             
             // Remove required attribute from separated weight fields
             maleWeightInput.removeAttribute('required');
             maleCountInput.removeAttribute('required');
             femaleWeightInput.removeAttribute('required');
             femaleCountInput.removeAttribute('required');
             
             // Clear separated weight values
             maleWeightInput.value = '';
             maleCountInput.value = '';
             femaleWeightInput.value = '';
             femaleCountInput.value = '';
         }
     }
     
     function collectWeightData() {
         const chickenAge = parseInt(document.getElementById('chickenAge').value);
         const weightData = {
             chickenAge: chickenAge
         };
         
         if (chickenAge >= 18) {
             // Collect separated weight data
             weightData.separatedWeights = {
                 male: {
                     weight: parseFloat(document.getElementById('maleWeight').value) || 0,
                     count: parseInt(document.getElementById('maleCount').value) || 0
                 },
                 female: {
                     weight: parseFloat(document.getElementById('femaleWeight').value) || 0,
                     count: parseInt(document.getElementById('femaleCount').value) || 0
                 }
             };
             
             // Calculate total weight and count
             weightData.totalWeight = weightData.separatedWeights.male.weight + weightData.separatedWeights.female.weight;
             weightData.totalCount = weightData.separatedWeights.male.count + weightData.separatedWeights.female.count;
         } else {
             // Collect combined weight data
             weightData.totalWeight = parseFloat(document.getElementById('totalWeight').value) || 0;
             weightData.totalCount = parseInt(document.getElementById('chickenCount').value) || 0;
         }
         
         // Calculate average weight per chicken
         weightData.averageWeight = weightData.totalCount > 0 ? (weightData.totalWeight / weightData.totalCount).toFixed(3) : 0;
         
         return weightData;
     }
     
     function validateWeightData() {
         const chickenAge = parseInt(document.getElementById('chickenAge').value);
         let isValid = true;
         
         if (chickenAge < 18) {
              // Validate combined weight fields
              const combinedWeight = document.getElementById('combinedWeight');
              const combinedCount = document.getElementById('combinedCount');
              
              if (combinedWeight.value === '' || isNaN(combinedWeight.value) || parseFloat(combinedWeight.value) < 0) {
                  addInvalidFeedback(combinedWeight, 'Please enter a valid weight (0 or greater)');
                  isValid = false;
              }
              
              if (combinedCount.value === '' || isNaN(combinedCount.value) || parseInt(combinedCount.value) < 0) {
                  addInvalidFeedback(combinedCount, 'Please enter a valid count (0 or greater)');
                  isValid = false;
              }
         } else {
             // Validate separated weight fields
             const maleWeight = document.getElementById('maleWeight');
             const maleCount = document.getElementById('maleCount');
             const femaleWeight = document.getElementById('femaleWeight');
             const femaleCount = document.getElementById('femaleCount');
             
             if (maleWeight.value === '' || isNaN(maleWeight.value) || parseFloat(maleWeight.value) < 0) {
                 addInvalidFeedback(maleWeight, 'Please enter a valid male weight (0 or greater)');
                 isValid = false;
             }
             
             if (maleCount.value === '' || isNaN(maleCount.value) || parseInt(maleCount.value) < 0) {
                 addInvalidFeedback(maleCount, 'Please enter a valid male count (0 or greater)');
                 isValid = false;
             }
             
             if (femaleWeight.value === '' || isNaN(femaleWeight.value) || parseFloat(femaleWeight.value) < 0) {
                 addInvalidFeedback(femaleWeight, 'Please enter a valid female weight (0 or greater)');
                 isValid = false;
             }
             
             if (femaleCount.value === '' || isNaN(femaleCount.value) || parseInt(femaleCount.value) < 0) {
                 addInvalidFeedback(femaleCount, 'Please enter a valid female count (0 or greater)');
                 isValid = false;
             }
         }
         
         return isValid;
     }
     
     function collectMedicationData() {
         const medicationData = {
             morning: [],
             afternoon: [],
             evening: []
         };
         
         // Collect medications for each time period
         ['morning', 'afternoon', 'evening'].forEach(period => {
             const medicationsList = document.getElementById(`${period}-medications`);
             const medicationEntries = medicationsList.querySelectorAll('.medication-entry');
             
             medicationEntries.forEach(entry => {
                 const medicationSelect = entry.querySelector('.medication-select');
                 const medicationAmount = entry.querySelector('.medication-amount');
                 const medicationUnit = entry.querySelector('.medication-unit');
                 const otherMedicationInput = entry.querySelector('.other-medication-input');
                 
                 if (medicationSelect.value) {
                     const medicationEntry = {
                         medication: medicationSelect.value,
                         amount: medicationAmount.value,
                         unit: medicationUnit.value
                     };
                     
                     // Add other medication name if specified
                     if (medicationSelect.value === 'other' && otherMedicationInput.value) {
                         medicationEntry.otherMedication = otherMedicationInput.value;
                     }
                     
                     medicationData[period].push(medicationEntry);
                 }
             });
         });
         
         return medicationData;
    }
    
    function validateMedications() {
        let isValid = true;
        
        // Check each time period for medication entries
        ['morning', 'afternoon', 'evening'].forEach(period => {
            const medicationsList = document.getElementById(`${period}-medications`);
            const medicationEntries = medicationsList.querySelectorAll('.medication-entry');
            
            medicationEntries.forEach(entry => {
                const medicationSelect = entry.querySelector('.medication-select');
                const medicationAmount = entry.querySelector('.medication-amount');
                const otherMedicationInput = entry.querySelector('.other-medication-input');
                
                // Validate medication selection
                if (!medicationSelect.value) {
                    addInvalidFeedback(medicationSelect, 'Please select a medication');
                    isValid = false;
                }
                
                // Validate amount
                if (!medicationAmount.value.trim()) {
                    addInvalidFeedback(medicationAmount, 'Please enter amount/quantity');
                    isValid = false;
                }
                
                // Validate other medication if selected
                if (medicationSelect.value === 'other' && !otherMedicationInput.value.trim()) {
                    addInvalidFeedback(otherMedicationInput, 'Please specify the medication name');
                    isValid = false;
                }
            });
        });
        
        return isValid;
    }
    
    // Form submission
    const checkinForm = document.getElementById('checkin-form');
    
    checkinForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Validate form
        if (!validateForm()) {
            return false;
        }
        
        // Collect form data
        const formData = {
            workerName: document.getElementById('workerName').value,
            date: document.getElementById('date').value,
            deadChickens: document.getElementById('deadChickens').value,
            chickenAge: parseInt(document.getElementById('chickenAge').value),
            weightData: collectWeightData(),
            feedAmount: document.getElementById('feedAmount').value,
            notes: document.getElementById('notes').value,
            medications: collectMedicationData()
        };
        
        // Send data to backend
        submitData(formData);
    });
    
    // Form validation function
    function validateForm() {
        let isValid = true;
        
        // Reset previous validation
        const invalidElements = document.querySelectorAll('.is-invalid');
        invalidElements.forEach(element => {
            element.classList.remove('is-invalid');
        });
        
        // Remove previous feedback messages
        const feedbackElements = document.querySelectorAll('.invalid-feedback');
        feedbackElements.forEach(element => {
            element.remove();
        });
        
        // Validate worker name
        const workerName = document.getElementById('workerName');
        if (!workerName.value.trim()) {
            addInvalidFeedback(workerName, 'Worker name is required');
            isValid = false;
        }
        
        // Validate dead chickens
        const deadChickens = document.getElementById('deadChickens');
        if (deadChickens.value === '' || isNaN(deadChickens.value) || parseInt(deadChickens.value) < 0) {
            addInvalidFeedback(deadChickens, 'Please enter a valid number (0 or greater)');
            isValid = false;
        }
        
        // Validate chicken age
        const chickenAge = document.getElementById('chickenAge');
        if (chickenAge.value === '' || isNaN(chickenAge.value) || parseInt(chickenAge.value) < 1 || parseInt(chickenAge.value) > 365) {
            addInvalidFeedback(chickenAge, 'Please enter a valid age between 1 and 365 days');
            isValid = false;
        }
        
        // Validate weight data based on chicken age
        isValid = validateWeightData() && isValid;
        
        // Validate medications
        isValid = validateMedications() && isValid;
        
        // Validate feed amount
        const feedAmount = document.getElementById('feedAmount');
        if (feedAmount.value === '' || isNaN(feedAmount.value) || parseFloat(feedAmount.value) < 0) {
            addInvalidFeedback(feedAmount, 'Please enter a valid feed amount');
            isValid = false;
        }
        
        return isValid;
    }
    
    // Helper function to add invalid feedback
    function addInvalidFeedback(element, message) {
        element.classList.add('is-invalid');
        const feedback = document.createElement('div');
        feedback.classList.add('invalid-feedback');
        feedback.textContent = message;
        element.parentNode.appendChild(feedback);
    }
    
    // Function to submit data to local storage
    function submitData(formData) {
        // Show loading state
        const submitButton = checkinForm.querySelector('button[type="submit"]');
        const originalButtonText = submitButton.textContent;
        submitButton.textContent = 'Submitting...';
        submitButton.disabled = true;
        
        // Add user information from session
        const userData = JSON.parse(sessionStorage.getItem('userData'));
        formData.workerName = userData.name; // Use the authenticated user's name
        
        // Add unique ID and timestamp
        formData.id = 'checkin-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
        formData.timestamp = new Date().toISOString();
        
        try {
            // Get existing check-in data from localStorage
            let existingData = localStorage.getItem('sampleCheckinData');
            let checkinArray = [];
            
            if (existingData) {
                checkinArray = JSON.parse(existingData);
            }
            
            // Add new check-in to the beginning of the array
            checkinArray.unshift(formData);
            
            // Store updated data back to localStorage
            localStorage.setItem('sampleCheckinData', JSON.stringify(checkinArray));
            
            // Show success message
            showMessage('success', 'Check-in data submitted successfully!');
            
            // Reset form
            checkinForm.reset();
            document.getElementById('date').valueAsDate = new Date();
            
            // Clear all medication entries
            ['morning', 'afternoon', 'evening'].forEach(period => {
                const medicationsList = document.getElementById(`${period}-medications`);
                medicationsList.innerHTML = '';
            });
            
            // Reset medication counter
            medicationCounter = 0;
            
        } catch (error) {
            console.error('Error saving data:', error);
            showMessage('error', 'An error occurred while saving data. Please try again.');
        }
        
        // Reset button state
        submitButton.textContent = originalButtonText;
        submitButton.disabled = false;
    }
    
    // Function to show success or error messages
    function showMessage(type, message) {
        // Remove any existing alerts
        const existingAlerts = document.querySelectorAll('.alert');
        existingAlerts.forEach(alert => {
            alert.remove();
        });
        
        // Create new alert
        const alertDiv = document.createElement('div');
        alertDiv.classList.add('alert', type === 'success' ? 'alert-success' : 'alert-danger');
        alertDiv.textContent = message;
        
        // Insert alert before the form
        checkinForm.parentNode.insertBefore(alertDiv, checkinForm);
        
        // Auto-dismiss after 5 seconds
        setTimeout(function() {
            alertDiv.remove();
        }, 5000);
    }
    
    // Dark mode initialization function
    function initializeDarkMode() {
        const savedTheme = localStorage.getItem('darkMode');
        const isDarkMode = savedTheme === 'true';
        
        if (isDarkMode) {
            document.body.classList.add('dark-mode');
        }
        
        updateThemeToggleText(isDarkMode);
    }
    
    // Update theme toggle text
    function updateThemeToggleText(isDarkMode) {
        const themeToggle = document.getElementById('theme-toggle');
        if (themeToggle) {
            themeToggle.textContent = isDarkMode ? '☀️' : '🌙';
        }
    }
    
    // Language initialization function
    function initializeLanguage() {
        const savedLanguage = localStorage.getItem('selectedLanguage') || 'en';
        const languageSelect = document.getElementById('language-select');
        if (languageSelect) {
            languageSelect.value = savedLanguage;
        }
        updatePageLanguage(savedLanguage);
    }
    
    // Use centralized translation system
    
    // Update page language function
    function updatePageLanguage(language) {
        // Use the centralized translator
        translator.setLanguage(language);
        
        // Update page title
        document.title = translator.t('checkin_title');
        
        // Update header
        const headerTitle = document.querySelector('.header h1');
        if (headerTitle) headerTitle.textContent = translator.t('checkin_title');
        
        const welcomeText = document.querySelector('#user-name');
        if (welcomeText && userData) {
            welcomeText.textContent = `${translator.t('welcome_text')}, ${userData.name}`;
        }
        
        const logoutBtn = document.querySelector('#logout-btn');
        if (logoutBtn) logoutBtn.textContent = translator.t('logout');
        
        // Update form elements
        const formTitle = document.querySelector('.card-title');
        if (formTitle) formTitle.textContent = translator.t('form_title');
        
        // Update labels
        updateLabel('workerName', translator.t('worker_name_field'));
        updateLabel('date', translator.t('date_field'));
        updateLabel('deadChickens', translator.t('dead_chickens_field'));
        updateLabel('chickenAge', translator.t('chicken_age'));
        updateLabel('combinedWeight', translator.t('combined_weight'));
        updateLabel('maleWeight', translator.t('male_weight'));
        updateLabel('femaleWeight', translator.t('female_weight'));
        updateLabel('feedConsumption', translator.t('feed_consumption'));
        updateLabel('notes', translator.t('notes'));
        
        // Update section headers
        const chickenTrackingHeader = document.querySelector('h5');
        if (chickenTrackingHeader && chickenTrackingHeader.textContent.includes('Chicken')) {
            chickenTrackingHeader.textContent = translator.t('chicken_tracking');
        }
        
        // Update submit button
        const submitBtn = document.querySelector('button[type="submit"]');
        if (submitBtn) submitBtn.textContent = translator.t('submit');
        
        // Update medication management
        const medicationHeaders = document.querySelectorAll('h6');
        medicationHeaders.forEach(header => {
            if (header.textContent.includes('Medication')) {
                header.textContent = translator.t('medication_management');
            }
        });
        
        // Update tab labels
        updateTabLabel('morning-tab', translator.t('morning'));
        updateTabLabel('afternoon-tab', translator.t('afternoon'));
        updateTabLabel('evening-tab', translator.t('evening'));
        
        // Update add medication buttons
        const addMedicationBtns = document.querySelectorAll('.add-medication-btn');
        addMedicationBtns.forEach(btn => {
            btn.textContent = translator.t('add_medication');
        });
    }
    
    function updateLabel(forId, text) {
        const label = document.querySelector(`label[for="${forId}"]`);
        if (label) label.textContent = text;
    }
    
    function updateTabLabel(tabId, text) {
        const tab = document.getElementById(tabId);
        if (tab) tab.textContent = text;
    }
    
    // Initialize language functionality
    initializeLanguage();
});