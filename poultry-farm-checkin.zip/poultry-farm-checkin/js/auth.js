// Authentication helper functions

document.addEventListener('DOMContentLoaded', function() {
    // Check if user is logged in
    function checkAuth() {
        const userData = JSON.parse(sessionStorage.getItem('userData') || '{}');
        
        if (!userData.username) {
            // Redirect to login page if not logged in
            window.location.href = 'standalone-login.html';
            return;
        }
        
        // For worker page, check if user has worker role
        if (window.location.pathname.includes('index.html') || window.location.pathname.endsWith('/')) {
            if (userData.role !== 'worker') {
                // If admin tries to access worker page, redirect to admin dashboard
                window.location.href = 'admin/index.html';
                return;
            }
        }
        
        // Display user name
        const userNameElement = document.getElementById('user-name');
        if (userNameElement) {
            userNameElement.textContent = `Welcome, ${userData.name || userData.username}`;
        }
        
        // Set worker name in form if on worker page
        const workerNameInput = document.getElementById('workerName');
        if (workerNameInput) {
            workerNameInput.value = userData.name || userData.username;
        }
    }
    
    // Handle logout
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function() {
            // Clear session storage
            sessionStorage.removeItem('userData');
            
            // Redirect to login page
            window.location.href = 'standalone-login.html';
        });
    }
    
    // Check authentication on page load
    checkAuth();
});