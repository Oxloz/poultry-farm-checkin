# Poultry Farm Check-in System

A comprehensive web application for managing daily poultry farm operations, worker check-ins, and medication expense tracking.

## Features

### Worker Interface
- **Secure Authentication**: Worker login system with predefined usernames
- **Daily Check-ins**: Submit daily data including dead chickens, medication used, feed amount
- **Mobile-Friendly**: Responsive design works on all devices
- **Data Validation**: Client-side validation ensures data accuracy
- **Confirmation System**: Clear feedback after successful submissions

### Admin Dashboard
- **Analytics Overview**: Total check-ins, dead chickens, medication usage, feed amounts
- **Data Management**: View, filter, and export all check-in data
- **Medication Tracking**: Monitor medication expenses with visual charts
- **Worker Management**: Track individual worker performance
- **Export Capabilities**: Download data as CSV for analysis
- **Visual Charts**: Pie charts for medication expenses and usage trends

## 🚀 Quick Start

### Local Testing
1. Download all files to a folder
2. Open terminal in the project folder
3. Run: `python -m http.server 8000` (or `ruby -run -e httpd . -p 8000`)
4. Visit: `http://localhost:8000`

### Live Deployment
For deploying to your domain (like `oxloz.com`), see the detailed **[DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md)** which covers:
- **GitHub Pages** (recommended - completely free)
- **Netlify** (alternative with extra features)
- **Traditional hosting**
- DNS configuration
- HTTPS setup

## File Structure

```
poultry-farm-checkin/
├── index.html          # Main worker interface
├── style.css           # Main stylesheet
├── script.js           # Main application logic
├── admin/
│   ├── index.html      # Admin dashboard
│   ├── admin.css       # Admin styles
│   └── admin.js        # Admin functionality
├── DEPLOYMENT_GUIDE.md # Deployment instructions
└── README.md           # This file
```

## Technology Stack

- **Frontend**: HTML5, CSS3, JavaScript (ES6+)
- **Charts**: Chart.js for data visualization
- **Storage**: localStorage (client-side data persistence)
- **Responsive**: CSS Grid and Flexbox
- **No Backend Required**: Pure client-side application

## Usage Guide

### For Workers

1. Open the application in your web browser
2. Log in with your assigned username (Labir, Surya, Xingmei, Dicky, Jaya, or Nandir)
3. Fill in the daily check-in form:
   - Date (defaults to current date)
   - Number of dead chickens found (if any)
   - Medication used and amounts
   - Feed amount distributed
   - Additional notes
4. Submit the form to record your daily check-in

### For Administrators

1. Access the admin panel at `/admin/`
2. Log in with credentials: admin/admin123
3. View dashboard with:
   - Summary statistics
   - Recent check-ins table
   - Medication expense charts
   - Worker performance data
4. Use filters to analyze specific data
5. Export data as CSV for external analysis
6. Manage medication pricing in the admin panel

## Data Storage

The application uses browser localStorage for data persistence:
- Data is stored locally in each user's browser
- Data won't be shared between different devices/browsers
- For production use with multiple devices, consider implementing a backend database
- Regular data exports recommended for backup

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Security

- Client-side authentication (suitable for internal farm use)
- No sensitive data transmitted over network
- HTTPS recommended for production deployment
- All data stored locally in browser

## 📋 Deployment Options

### Free Hosting (Recommended)
- **GitHub Pages**: Completely free, reliable, integrated with Git version control
- **Netlify**: Free tier with advanced features like form handling
- **Vercel**: Free for personal projects

### Traditional Hosting
- Any web hosting provider
- Upload files via FTP/cPanel
- Configure domain DNS

## Support

For deployment assistance, see the comprehensive `DEPLOYMENT_GUIDE.md` included with this project.

## License

This project is designed for internal poultry farm management use.